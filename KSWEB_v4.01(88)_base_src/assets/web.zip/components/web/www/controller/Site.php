<?php
    
    class Site extends Controller {

        public function __construct($engine) {
            parent::__construct($engine);
            $this->includeBaseResources();
            $this->layout = "./layouts/layout.php";
        }

        function actionIndex() {           
            $this->params['title'] = "KSWEB WebFace";

            $server = new Server();

            switch ($server->getServerType()) {
                case Server::NGINX:

                    $serverInfo = $server->getServerInfoNginx();

                    $this->params["serverInfo"] = $serverInfo;

                    $this->render("views/indexNginx.php");
                    break;
                default:
                    $authInfo = $server->getAuth();

                    $context = stream_context_create(array(
                        'http' => array(
                            'header' => "Authorization: Basic " . base64_encode($authInfo["login"] . ":" . $authInfo["password"])
                        )
                    ));

                    $html = file_get_contents("http://127.0.0.1:" . $_SERVER['SERVER_PORT'] . "/server-status", false, $context);

					$html = preg_replace('/<![^>]+>/i', '', $html);
					$html = preg_replace('#<script\b[^>]*>.*?</script>#is', '', $html);

					$allowedTags = '<meta><hr><style><dl><dt><pre><p><title><html><head><body><h1><h2><h4><table><thead><tbody><tr><td><th>';
					$html = strip_tags($html, $allowedTags);

                    $search = array(
                        '<h1>',
                        '</h1>',
                        '<h2>',
                        '</h2>',
                        '<table summary="status" class="status">'
                    );
                    $replace = array(
                        '<h4>',
                        '</h4>',
                        '<h4>',
                        '</h4>',
                        '<table class="striped">'
                    );
                    $html = str_replace($search, $replace, $html);

                    $this->params['html'] = $html;

                    $this->render("views/index.php");
            }
        }

        function actionRestartservers() {
            $this->params['title'] = "Restart Servers";
            $this->render("views/restartServers.php");
        }

        function actionRequestrestartservers() {
            $tmpFolder = KSWEBEnv::TMP_EXTERNAL_DIR;
            @mkdir($tmpFolder);
            $restartMarker = $tmpFolder.'/restart';
            @unlink($restartMarker);
            $ourFileName = $restartMarker;
            $ourFileHandle = fopen($ourFileName, 'w');

            if (!$ourFileHandle) {
                echo "Can't create server restart marker on sdcard!";
                return;
            } else {
                fclose($ourFileHandle);
                echo "Servers were restarted!";
            }
        }

        function actionWebserverconf() {
            $this->params['title'] = "Server Configuration";
            $this->render("views/configuration.php");
        }

        function actionMysqlconf() {
            $this->params['title'] = "MySQL Configuration";
            $this->render("views/configuration.php");
        }

        function actionPhpconf() {
            $this->params['title'] = "PHP Configuration";
            $this->render("views/configuration.php");
        }

        /*function actionKswebsettings() {
            $this->params['title'] = "KSWEB Settings";
            $this->render("views/kswebsettings.php");
        }*/

        function actionPhpinfo() {
            $this->params['title'] = "PHP INFO";
            phpinfo();
        }

        function actionSavesystemsettings() {
            $settings["current_password"] = base64_decode(filter_input(INPUT_POST, 'current_password'));
            $settings["new_password"] = base64_decode(filter_input(INPUT_POST, 'new_password'));
            $settings["confirm_password"] = base64_decode(filter_input(INPUT_POST, 'confirm_password'));

            if (empty($settings["current_password"]) ||
                empty($settings["new_password"]) ||
                empty($settings["confirm_password"])) {
                echo "All fields must be filled up!";
                return;
            }

            if ($settings["new_password"] == $settings["confirm_password"]) {
                $server = new Server();
                $authInfo = $server->getAuth();

                if ($settings["current_password"] == $authInfo["password"]) {
                    $password = $settings["new_password"];

                    $serverType = $server->getServerType();
                    if ($serverType == Server::LIGHTTPD ) {
                        unlink(Server::LIGHTTPD_FOLDER_PASS);
                        $fp = fopen(Server::LIGHTTPD_FOLDER_PASS, "a");
                        fwrite($fp, "admin:$password");
                        fclose($fp);
                    }

                    if ($serverType == Server::APACHE) {
                        unlink(Server::APACHE_FOLDER_PASS);
                        $fp = fopen(Server::APACHE_FOLDER_PASS, "a");
                        fwrite($fp, "admin:$password");
                        fclose($fp);
                    }

                    if ($serverType == Server::NGINX) {
                        unlink(Server::NGINX_FOLDER_PASS);
                        $fp = fopen(Server::NGINX_FOLDER_PASS, "a");
                        fwrite($fp, "admin:{PLAIN}$password");
                        fclose($fp);
                    }

                    echo "Your password has been changed!";
                } else {
                    echo "The current password you've entered is incorrect. Please enter a different password!";
                }
            } else {
                echo "New password must be confirmed correctly!";
            }

        }

        function actionSavekswebsettings() {
            $settings["is_start_min"] = filter_input(INPUT_POST, 'is_start_min');
            $settings["is_start_min_old"] = filter_input(INPUT_POST, 'is_start_min_old');
            $settings["auto_start"] = filter_input(INPUT_POST, 'auto_start');
            $settings["auto_start_old"] = filter_input(INPUT_POST, 'auto_start_old');
            $settings["move_inis"] = filter_input(INPUT_POST, 'move_inis');
            $settings["move_inis_old"] = filter_input(INPUT_POST, 'move_inis_old');
            $settings["wifiLock"] = filter_input(INPUT_POST, 'wifiLock');
            $settings["wifiLock_old"] = filter_input(INPUT_POST, 'wifiLock_old');

            if (!isset($settings["is_start_min"]) ||
                !isset($settings["is_start_min_old"]) ||
                !isset($settings["auto_start"]) ||
                !isset($settings["auto_start_old"]) ||
                !isset($settings["move_inis"]) ||
                !isset($settings["move_inis_old"]) ||
                !isset($settings["wifiLock"]) ||
                !isset($settings["wifiLock_old"])) {
                echo "WRONG REQUEST";
                return;
            }

            $s = new KSWEBSettings();

            if ($settings["is_start_min_old"] != $settings["is_start_min"]) {
                $s->set("enableStartMinimized", $settings["is_start_min"]);
            }

            if ($settings["auto_start_old"] != $settings["auto_start"]) {
                $s->set("enableAutoStart", $settings["auto_start"]);
            }

            if ($settings["move_inis_old"] != $settings["move_inis"]) {
                if($settings["move_inis"] == "true") {
                    if (!Config::copyAllConfigFiles()) {
                        echo "<p>Not all configuration files was copied!</p>";
                    }
                    Config::copyAllHosts();
                    echo "<p>All configuration files was placed to external KSWEB folder: '".KSWEBEnv::CONF_EXTERNAL_DIR."'</p>";
                }
                $s->set("externalINI", $settings["move_inis"]);
            }

            if ($settings["wifiLock_old"] != $settings["wifiLock"]) {
                $s->set("wifiLock", $settings["wifiLock"]);
            }
        }

        function actionSystemsettings() {
            $this->configuration->addJS("web/js/jquery.base64.min.js");
            $this->params['title'] = "System Settings";
            $this->render("views/systemsettings.php");
        }

        function actionSavesettings() {
            $configType = filter_input(INPUT_POST, 'configType');
            $hostnameRaw = filter_input(INPUT_POST, 'hostname');
            $content = filter_input(INPUT_POST, 'content');
            
			$hostname = preg_replace('/[^a-zA-Z0-9\.\-_]/', '', (string)$hostnameRaw);
			
            if (isset($configType) && isset($content)) {

                if ($configType == ConfigType::LIGHTTPD_HOST || $configType == ConfigType::NGINX_HOST || $configType == ConfigType::APACHE_HOST) {
                    if (!isset($hostname)) {
                        echo "WRONG REQUEST";
                        return;
                    }
                }
                
                $config = new Config($configType, $this->engine, $hostname);

                $results = $config->testConfig($content);

                $saved = false;
                $message = "";
                if ($results["testOk"]) {
                    $saved = $config->saveConfig();
                    if ($saved) {
                        $message = "Configuration saved!";
                    } else {
                        $message = "There are errors during saving configuration file!";
                    }
                } else {
                    $message = $results["message"];
                }

                
                $answer["message"] = $message;
                $answer["saved"] = $saved;
                
                echo json_encode($answer);
            } else {
                echo "WRONG REQUEST";
            }
        }
    }