<?
require_once './core/Engine.php';

//error_reporting(E_ALL);
//ini_set('display_error', 'on');

(new Engine())->start();