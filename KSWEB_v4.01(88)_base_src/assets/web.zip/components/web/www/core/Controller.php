<?php

    abstract class Controller {
        var $layout;

        /**
         * @var Engine
         */
        var $engine;

        var $params;
        var $configuration;
        
        public function __construct($engine) {
            $this->engine = $engine;
            $this->params['engine'] = $engine;
            $this->configuration = new Configuration();
        }
        
        public function includeBaseResources() {
            $this->configuration->addCSS("web/css/materialize.min.css");
            $this->configuration->addCSS("web/css/styles.css");
            
            $this->configuration->addJS("web/js/jquery.min.js");
            $this->configuration->addJS("web/js/materialize.min.js");
        }

        public function getConfiguration() {
            return $this->configuration;
        }

        public function generateJSScriptsHtml() {
            $content = "";
            foreach ($this->configuration->getJSSctipts() as $jsScript) {
				$safeUrl = htmlspecialchars($jsScript, ENT_QUOTES, 'UTF-8');
                $content .= "<script src='{$safeUrl}'></script>\r\n";
            }
            return $content;
        }
        
        public function generateCSSStylesHtml() {
            $content = "";
            foreach ($this->configuration->getCSSStyles() as $cssStyle) {
                $safeUrl = htmlspecialchars($cssStyle, ENT_QUOTES, 'UTF-8');
                $content .= "<link href='{$safeUrl}' rel='stylesheet'>\r\n";
            }
            return $content;
        }

        function render($view) {
            $params = $this->params;
            $engine = $this->engine;
			//!!!
			$viewPath = realpath($view);
            ob_start();
            include $viewPath;
            $content = ob_get_clean();
            $title = $this->params['title'];
            include $this->layout;
        }
    }