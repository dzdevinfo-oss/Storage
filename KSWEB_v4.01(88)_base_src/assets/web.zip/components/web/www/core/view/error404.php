<div class="container">
    <div class="span">
        <h1>Error 404</h1>
        <p>The page you are looking for isn't found here! :-(</p>
    </div>
</div>