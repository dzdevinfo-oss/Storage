<div class="container">
    <div class="span">
        <h1>Access Denied</h1>
        <p>Oops, you can't be here!</p>
    </div>
</div>