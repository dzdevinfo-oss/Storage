<?php

class CoreController extends Controller {
    public function __construct($engine) {
        parent::__construct($engine);
        $this->includeBaseResources();
        $this->layout = "./layouts/layout.php";
    }

    function actionError404() {
        $this->params['title'] = "Page Not Found!";
        $this->render("core/view/error404.php");
    }

    function actionAccessDenied() {
        $this->private = false;
        $this->params['title'] = "Access Denied!";
        $this->render("core/view/accessDenied.php");
    }
}