<?php
	class KSWEBEnv {
	    //KSWEB APP
const APP_INTERNAL_DIR = "/data/user/0/ru.kslabs.ksweb";
const APP_EXTERNAL_DIR = "/storage/emulated/0/ksweb";

		//TEMP
const TMP_INTERNAL_DIR = "/data/user/0/ru.kslabs.ksweb/tmp";
const TMP_EXTERNAL_DIR = "/storage/emulated/0/ksweb/tmp";

		//CONFIG
const CONFIG_EXTERNAL_DIR = "/storage/emulated/0/ksweb/conf";

		//PHP
const PHP_CONFIG_INTERNAL_FILEPATH = "/data/user/0/ru.kslabs.ksweb/components/php/conf/php.ini";
const PHP_CONFIG_INTERNAL_DIR = "/data/user/0/ru.kslabs.ksweb/components/php/conf";
const PHP_CONFIG_EXTERNAL_FILEPATH = "/storage/emulated/0/ksweb/conf/php/php.ini";


        //MySQL
const MYSQL_CONFIG_INTERNAL_FILEPATH = "/data/user/0/ru.kslabs.ksweb/components/mysql/conf/my.ini";
const MYSQL_CONFIG_EXTERNAL_DIR = "/storage/emulated/0/ksweb/conf/mysql";
const MYSQL_CONFIG_EXTERNAL_FILEPATH = "/storage/emulated/0/ksweb/conf/mysql/my.ini";
const MYSQL_LANGUAGE_FILEPATH = "/data/user/0/ru.kslabs.ksweb/components/mysql/sbin/share/mysql/english";
const MYSQLD_BIN_FILEPATH = "/data/app/~~8PofO7oq_Al3jXLPGaf55g==/ru.kslabs.ksweb-esNJLqWy19tBWVCk3tCHTQ==/lib/arm64/libsqld-10-4-34-api24.so";

        //Lighttpd
const LIGHTTPD_CONFIG_INTERNAL_DIR = "/data/user/0/ru.kslabs.ksweb/components/lighttpd/conf";
const LIGHTTPD_CONFIG_INTERNAL_FILEPATH = "/data/user/0/ru.kslabs.ksweb/components/lighttpd/conf/lighttpd.conf";
const LIGHTTPD_CONFIG_EXTERNAL_DIR = "/storage/emulated/0/ksweb/conf/lighttpd";
const LIGHTTPD_CONFIG_EXTERNAL_FILEPATH = "/storage/emulated/0/ksweb/conf/lighttpd/lighttpd.conf";
const LIGHTTPD_BIN_FILEPATH = "/data/app/~~8PofO7oq_Al3jXLPGaf55g==/ru.kslabs.ksweb-esNJLqWy19tBWVCk3tCHTQ==/lib/arm64/liblhttpd.so";
const LIGHTTPD_LD_DIR = "/data/app/~~8PofO7oq_Al3jXLPGaf55g==/ru.kslabs.ksweb-esNJLqWy19tBWVCk3tCHTQ==/lib/arm64";

        //Nginx
const NGINX_CONFIG_INTERNAL_DIR = "/data/user/0/ru.kslabs.ksweb/components/nginx/conf";
const NGINX_CONFIG_INTERNAL_FILEPATH = "/data/user/0/ru.kslabs.ksweb/components/nginx/conf/nginx.conf";
const NGINX_CONFIG_EXTERNAL_DIR = "/storage/emulated/0/ksweb/conf/nginx";
const NGINX_CONFIG_EXTERNAL_FILEPATH = "/storage/emulated/0/ksweb/conf/nginx/nginx.conf";
const NGINX_BIN_FILEPATH = "/data/app/~~8PofO7oq_Al3jXLPGaf55g==/ru.kslabs.ksweb-esNJLqWy19tBWVCk3tCHTQ==/lib/arm64/libngx.so";
const NGINX_LD_DIR = "/data/app/~~8PofO7oq_Al3jXLPGaf55g==/ru.kslabs.ksweb-esNJLqWy19tBWVCk3tCHTQ==/lib/arm64";

        //Apache
const APACHE_CONFIG_INTERNAL_DIR = "/data/user/0/ru.kslabs.ksweb/components/httpd/conf";
const APACHE_CONFIG_INTERNAL_FILEPATH = "/data/user/0/ru.kslabs.ksweb/components/httpd/conf/httpd.conf";
const APACHE_CONFIG_EXTERNAL_DIR = "/storage/emulated/0/ksweb/conf/apache";
const APACHE_CONFIG_EXTERNAL_FILEPATH = "/storage/emulated/0/ksweb/conf/apache/httpd.conf";
const APACHE_BIN_FILEPATH = "/data/app/~~8PofO7oq_Al3jXLPGaf55g==/ru.kslabs.ksweb-esNJLqWy19tBWVCk3tCHTQ==/lib/arm64/libapac.so";
const APACHE_LD_DIR = "/data/app/~~8PofO7oq_Al3jXLPGaf55g==/ru.kslabs.ksweb-esNJLqWy19tBWVCk3tCHTQ==/lib/arm64";

        const TMP_CONFIG_FILEPATH               = KSWEBEnv::TMP_INTERNAL_DIR."/tempConfig.ini";
    }
?>
