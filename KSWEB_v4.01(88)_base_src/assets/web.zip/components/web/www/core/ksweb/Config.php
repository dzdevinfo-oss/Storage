<?php

class Config extends Env {

    private $currentConfig;
    private $type;
    private $server;

    public function __construct($configType, $engine, $hostname = "") {
        parent::__construct($engine);
        $settings = (new KSWEBSettings())->get();
        $move_inis = $settings["move_inis"];

        
        if ($configType == ConfigType::LIGHTTPD_HOST) {
            $this->currentConfig = ($move_inis == "true") ? KSWEBEnv::LIGHTTPD_CONFIG_EXTERNAL_DIR."/".$hostname : KSWEBEnv::LIGHTTPD_CONFIG_INTERNAL_DIR."/".$hostname;
            $this->server = Server::LIGHTTPD;
        }
        
        if ($configType == ConfigType::NGINX_HOST) {
            $this->currentConfig = ($move_inis == "true") ? KSWEBEnv::NGINX_CONFIG_EXTERNAL_DIR."/".$hostname : KSWEBEnv::NGINX_CONFIG_INTERNAL_DIR."/".$hostname;
            $this->server = Server::NGINX;
        }
        
        if ($configType == ConfigType::APACHE_HOST) {
            $this->currentConfig = ($move_inis == "true") ? KSWEBEnv::APACHE_CONFIG_EXTERNAL_DIR."/".$hostname : KSWEBEnv::APACHE_CONFIG_INTERNAL_DIR."/".$hostname;
            $this->server = Server::APACHE;
        }
        
        if ($configType == ConfigType::SERVER_LIGHTTPD) {
            $this->currentConfig = ($move_inis == "true") ? KSWEBEnv::LIGHTTPD_CONFIG_EXTERNAL_FILEPATH : KSWEBEnv::LIGHTTPD_CONFIG_INTERNAL_FILEPATH;
            $this->server = Server::LIGHTTPD;
        }

        if ($configType == ConfigType::SERVER_NGINX) {
            $this->currentConfig = ($move_inis == "true") ? KSWEBEnv::NGINX_CONFIG_EXTERNAL_FILEPATH : KSWEBEnv::NGINX_CONFIG_INTERNAL_FILEPATH;
            $this->server = Server::NGINX;
        }

        if ($configType == ConfigType::SERVER_APACHE) {
            $this->currentConfig = ($move_inis == "true") ? KSWEBEnv::APACHE_CONFIG_EXTERNAL_FILEPATH : KSWEBEnv::APACHE_CONFIG_INTERNAL_FILEPATH;
            $this->server = Server::APACHE;
        }

        if ($configType == ConfigType::PHP) {
            $this->currentConfig = ($move_inis == "true") ? KSWEBEnv::PHP_CONFIG_EXTERNAL_FILEPATH : KSWEBEnv::PHP_CONFIG_INTERNAL_FILEPATH;
            $this->server = Server::PHP;
        }

        if ($configType == ConfigType::MYSQL) {
            $this->currentConfig = ($move_inis == "true") ? KSWEBEnv::MYSQL_CONFIG_EXTERNAL_FILEPATH : KSWEBEnv::MYSQL_CONFIG_INTERNAL_FILEPATH;
            $this->server = Server::MYSQL;
        }

        $this->type = $configType;
		
        $allowedBaseDirs = [
            realpath(KSWEBEnv::LIGHTTPD_CONFIG_EXTERNAL_DIR),
            realpath(KSWEBEnv::LIGHTTPD_CONFIG_INTERNAL_DIR),
            realpath(KSWEBEnv::NGINX_CONFIG_EXTERNAL_DIR),
            realpath(KSWEBEnv::NGINX_CONFIG_INTERNAL_DIR),
            realpath(KSWEBEnv::APACHE_CONFIG_EXTERNAL_DIR),
            realpath(KSWEBEnv::APACHE_CONFIG_INTERNAL_DIR),
			
			realpath(KSWEBEnv::LIGHTTPD_CONFIG_EXTERNAL_FILEPATH),
            realpath(KSWEBEnv::LIGHTTPD_CONFIG_INTERNAL_FILEPATH),
            realpath(KSWEBEnv::NGINX_CONFIG_EXTERNAL_FILEPATH),
            realpath(KSWEBEnv::NGINX_CONFIG_INTERNAL_FILEPATH),
            realpath(KSWEBEnv::APACHE_CONFIG_EXTERNAL_FILEPATH),
            realpath(KSWEBEnv::APACHE_CONFIG_INTERNAL_FILEPATH),
			
			realpath(KSWEBEnv::PHP_CONFIG_EXTERNAL_FILEPATH),
            realpath(KSWEBEnv::PHP_CONFIG_INTERNAL_FILEPATH),
            realpath(KSWEBEnv::MYSQL_CONFIG_EXTERNAL_FILEPATH),
            realpath(KSWEBEnv::MYSQL_CONFIG_INTERNAL_FILEPATH),

            //realpath(dirname(Server::LIGHTTPD_FOLDER_PASS)), // Для файлов паролей
        ];

        $fullPath = realpath($this->currentConfig);
        $isPathSafe = false;

        foreach ($allowedBaseDirs as $dir) {
            if ($dir && strpos($fullPath, $dir) === 0) {
                $isPathSafe = true;
                break;
            }
        }

        if (!$isPathSafe || $fullPath === false) {
            header("HTTP/1.1 403 Forbidden");
            die("Security error: Attempted path traversal detected.");
        }
    }

    public function getConfigFullPath() {
        return $this->currentConfig;
    }

    public function getConfigFileName() {
        echo basename($this->currentConfig);
    }
    
    private function saveTMPConfig($content) {
        unlink(KSWEBEnv::TMP_CONFIG_FILEPATH);
        $fp = fopen(KSWEBEnv::TMP_CONFIG_FILEPATH, "a");
        fwrite($fp, $content);
        fclose($fp);
        shell_exec("chmod 644 ".KSWEBEnv::TMP_CONFIG_FILEPATH);
    }

    public function testConfig($content) {
        $this->saveTMPConfig($content);
        
        $message = "";
        $testOk = false;
        
        if ($this->type == ConfigType::SERVER_LIGHTTPD || $this->type == ConfigType::LIGHTTPD_HOST) {
            $output = str_replace("\n", "<br>", shell_exec("LD_LIBRARY_PATH=" . KSWEBEnv::LIGHTTPD_LD_DIR . " " . KSWEBEnv::LIGHTTPD_BIN_FILEPATH . " -t -f ".KSWEBEnv::TMP_CONFIG_FILEPATH." 2>&1"));
            $message = "============<br>Testing config...<br>" . $output . "============<br>";
            if (strpos($output, "yntax OK")) $testOk = true;
        }

        if ($this->type == ConfigType::PHP || $this->type == ConfigType::NGINX_HOST) {
            $testOk = true;
        }

        if ($this->type == ConfigType::MYSQL) {
            $output = str_replace("\n", "<br>", shell_exec(KSWEBEnv::MYSQLD_BIN_FILEPATH . " --defaults-file=".KSWEBEnv::TMP_CONFIG_FILEPATH." --lc-messages-dir=".KSWEBEnv::MYSQL_LANGUAGE_FILEPATH." --help --verbose 2>&1 1>/dev/null")); //1>/dev/null
            $message = "============<br>Testing config...<br>" . $output . "============<br>";
            if (!strpos($output, "[ERROR]")) {
                $testOk = true;
            }
        }
        if ($this->type == ConfigType::SERVER_NGINX) {
            $output = str_replace("\n", "<br>", shell_exec("LD_LIBRARY_PATH=" . KSWEBEnv::NGINX_LD_DIR . " " . KSWEBEnv::NGINX_BIN_FILEPATH . " -t -c ".KSWEBEnv::TMP_CONFIG_FILEPATH." 2>&1"));
            $message = "============<br>Testing config...<br>" . $output . "============<br>";
            if (strpos($output, "syntax is ok")) $testOk = true;
        }


        if ($this->type == ConfigType::SERVER_APACHE || $this->type == ConfigType::APACHE_HOST) {
            $output = str_replace("\n", "<br>", shell_exec("LD_LIBRARY_PATH=" . KSWEBEnv::APACHE_LD_DIR . " " . KSWEBEnv::APACHE_BIN_FILEPATH . " -t -f " . KSWEBEnv::TMP_CONFIG_FILEPATH . " 2>&1 1>/dev/null"));
            $message = "============<br>Testing config...<br>" . $output . "============<br>";
            if (strpos($output, "yntax OK")) {
                $testOk = true;
            }
        }

        if ($this->type == -1) {
            $testOk = true;
        }
        
        $result["testOk"] = $testOk;
        $result["message"] = $message;
        
        return $result;
    }

    public static function defineType($configFile) {
        if ($configFile == KSWEBEnv::PHP_CONFIG_INTERNAL_FILEPATH || $configFile == KSWEBEnv::PHP_CONFIG_EXTERNAL_FILEPATH) {
            return ConfigType::PHP;
        }
        if ($configFile == KSWEBEnv::MYSQL_CONFIG_INTERNAL_FILEPATH || $configFile == KSWEBEnv::MYSQL_CONFIG_EXTERNAL_FILEPATH) {
            return ConfigType::MYSQL;
        }
        if ($configFile == KSWEBEnv::LIGHTTPD_CONFIG_INTERNAL_FILEPATH || $configFile == KSWEBEnv::LIGHTTPD_CONFIG_EXTERNAL_FILEPATH) {
            return ConfigType::SERVER_LIGHTTPD;
        }
        if ($configFile == KSWEBEnv::NGINX_CONFIG_INTERNAL_FILEPATH || $configFile == KSWEBEnv::NGINX_CONFIG_EXTERNAL_FILEPATH) {
            return ConfigType::SERVER_NGINX;
        }
        if ($configFile == KSWEBEnv::APACHE_CONFIG_INTERNAL_FILEPATH || $configFile == KSWEBEnv::APACHE_CONFIG_EXTERNAL_FILEPATH) {
            return ConfigType::SERVER_APACHE;
        }
        return -1;
    }

    public function getConfigFileContent() {
        return file_get_contents($this->currentConfig);
    }

    public function saveConfig() {
        @unlink($this->getConfigFullPath());
        $result = copy(KSWEBEnv::TMP_CONFIG_FILEPATH, $this->getConfigFullPath());
        return $result;
    }

    private static function createConfDirOnSDCARD() {
        @mkdir(KSWEBEnv::CONF_EXTERNAL_DIR);
        @mkdir(KSWEBEnv::LIGHTTPD_CONFIG_EXTERNAL_DIR);
        @mkdir(KSWEBEnv::NGINX_CONFIG_EXTERNAL_DIR);
        @mkdir(KSWEBEnv::APACHE_CONFIG_EXTERNAL_DIR);
        @mkdir(KSWEBEnv::PHP_CONFIG_INTERNAL_DIR);
        @mkdir(KSWEBEnv::MYSQL_CONFIG_EXTERNAL_DIR);
    }

    public static function copyAllConfigFiles() {

        Config::createConfDirOnSDCARD();

		$result = true;

		//PHP
        $thing['source'] = KSWEBEnv::PHP_CONFIG_INTERNAL_FILEPATH;
        $thing['dest'] = KSWEBEnv::PHP_CONFIG_EXTERNAL_FILEPATH;
        $confFileArray[0] = $thing;

        //MYSQL
        $thing['source'] = KSWEBEnv::MYSQL_CONFIG_INTERNAL_FILEPATH;
        $thing['dest'] = KSWEBEnv::MYSQL_CONFIG_EXTERNAL_FILEPATH;
        $confFileArray[1] = $thing;

        //LIGHTTPD
        $thing['source'] = KSWEBEnv::LIGHTTPD_CONFIG_INTERNAL_FILEPATH;
        $thing['dest'] = KSWEBEnv::LIGHTTPD_CONFIG_EXTERNAL_FILEPATH;
        $confFileArray[2] = $thing;


        //NGINX
        $thing['source'] = KSWEBEnv::NGINX_CONFIG_INTERNAL_FILEPATH;
        $thing['dest'] = KSWEBEnv::NGINX_CONFIG_EXTERNAL_FILEPATH;
        $confFileArray[3] = $thing;


        //APACHE
        $thing['source'] = KSWEBEnv::APACHE_CONFIG_INTERNAL_FILEPATH;
        $thing['dest'] = KSWEBEnv::APACHE_CONFIG_EXTERNAL_FILEPATH;
        $confFileArray[4] = $thing;

        for ($i = 0; $i < count($confFileArray); $i++) {
            if (!copy($confFileArray[$i]['source'], $confFileArray[$i]['dest'])) {
                $result = false;
            }
        }

		return $result;
    }

    public static function copyAllHosts() {
        Config::deleteAllHostsFromSDLighttpd();
		
        $result = "";
		
        foreach (glob(KSWEBEnv::LIGHTTPD_CONFIG_INTERNAL_DIR."/*_host.conf") as $file) {
            if (copy($file, KSWEBEnv::LIGHTTPD_CONFIG_EXTERNAL_DIR ."/". basename($file))) {
                $result .= "Copied file: " . $file . " -> " . KSWEBEnv::LIGHTTPD_CONFIG_EXTERNAL_DIR ."/". basename($file) . "<br>";
            } else {
                $result .= "Error copying file: " . $file . " -> " . KSWEBEnv::LIGHTTPD_CONFIG_EXTERNAL_DIR ."/". basename($file) . "<br>";
            }
        }

        Config::deleteAllHostsFromSDNginx();
        foreach (glob(KSWEBEnv::NGINX_CONFIG_INTERNAL_DIR."/*_host.conf") as $file) {
            if (copy($file, KSWEBEnv::NGINX_CONFIG_EXTERNAL_DIR ."/". basename($file))) {
                $result .= "Copied file: " . $file . " -> " . KSWEBEnv::NGINX_CONFIG_EXTERNAL_DIR  ."/". basename($file) . "<br>";
            } else {
                $result .= "Error copying file: " . $file . " -> " . KSWEBEnv::NGINX_CONFIG_EXTERNAL_DIR  ."/". basename($file) . "<br>";
            }
        }

        Config::deleteAllHostsFromSDApache();
        foreach (glob(KSWEBEnv::APACHE_CONFIG_INTERNAL_DIR."/*_host.conf") as $file) {
            if (copy($file, KSWEBEnv::APACHE_CONFIG_EXTERNAL_DIR ."/". basename($file))) {
                $result .= "Copied file: " . $file . " -> " . KSWEBEnv::APACHE_CONFIG_EXTERNAL_DIR  ."/". basename($file) . "<br>";
            } else {
                $result .= "Error copying file: " . $file . " -> " . KSWEBEnv::APACHE_CONFIG_EXTERNAL_DIR  ."/". basename($file) . "<br>";
            }
        }

		return $result;
	}

    public static function deleteAllHostsFromSDLighttpd() {
        foreach (glob(KSWEBEnv::LIGHTTPD_CONFIG_EXTERNAL_DIR."/*_host.conf") as $file) {
            unlink($file);
        }
    }

    public static function deleteAllHostsFromSDNginx() {
        foreach (glob(KSWEBEnv::NGINX_CONFIG_EXTERNAL_DIR."/*_host.conf") as $file) {
            unlink($file);
        }
    }

    public static function deleteAllHostsFromSDApache() {
        foreach (glob(KSWEBEnv::APACHE_CONFIG_EXTERNAL_DIR."/*_host.conf") as $file) {
            unlink($file);
        }
    }

    public static function getConfigType($serverType) {
        if ($serverType == Server::LIGHTTPD) return ConfigType::SERVER_LIGHTTPD;
        if ($serverType == Server::NGINX) return ConfigType::SERVER_NGINX;
        if ($serverType == Server::APACHE) return ConfigType::SERVER_APACHE;
        return ConfigType::SERVER_LIGHTTPD;
    }
    
    function showServerConfigHref($server) {
        echo "<h5>".Server::getTextName($server)." config</h5><p>";
        if ($server == Server::LIGHTTPD) echo "<p><a class='blue-text text-darken-4' href = '".$this->engine->getUrl()->getCurrentAddress()."&server={$server}'>Config file: ".$this->getConfigFullPath()."</a></p>";
        if ($server == Server::NGINX) echo "<p><a class='blue-text text-darken-4' href = '".$this->engine->getUrl()->getCurrentAddress()."&server={$server}'>Config file: ".$this->getConfigFullPath()."</a></p>";
        if ($server == Server::APACHE) echo "<p><a class='blue-text text-darken-4' href = '".$this->engine->getUrl()->getCurrentAddress()."&server={$server}'>Config file: ".$this->getConfigFullPath()."</a></p>";
        echo "</p>";
    }
    
    function getHostListTxt() {
        $f = scandir(dirname($this->getConfigFullPath()));
        
        $newType = $this->type;
        switch ($this->type) {
            case ConfigType::SERVER_APACHE:
                $newType = ConfigType::APACHE_HOST;
                break;
            case ConfigType::SERVER_LIGHTTPD:
                $newType = ConfigType::LIGHTTPD_HOST;
                break;
            case ConfigType::SERVER_NGINX:
                $newType = ConfigType::NGINX_HOST;
                break;
        }
        
        $output = "";
        if ($f != false) {
            $title = "<h5>".Server::getTextName($this->server)." host files list</h5><p>";
            foreach($f as $file) {
                if (preg_match('/\_(host)/', $file)) {
                    $output .= "<p><a class='blue-text text-darken-4' href = '".$this->engine->getUrl()->getCurrentAddress()."&configType=".$newType."&hostname=$file'>Open host: ".$file."</a></p>";
                }
            }
            if ($output != "") { $output = $title.$output; }
        }
        return $output;
    }
}