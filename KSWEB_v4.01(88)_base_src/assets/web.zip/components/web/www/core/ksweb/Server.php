<?php

    class Server {
        const LIGHTTPD = 1;
        const NGINX = 2;
        const APACHE = 3;
        const PHP = 4;
        const MYSQL = 5;


        const LIGHTTPD_FOLDER_PASS = "/data/data/ru.kslabs.ksweb/components/etc/.pass";
        const NGINX_FOLDER_PASS = "/data/data/ru.kslabs.ksweb/components/etc/.pass_nginx";
        const APACHE_FOLDER_PASS = "/data/data/ru.kslabs.ksweb/components/etc/.pass_apache";
        
        const LIGHTTPD_TXT_NAME = "Lighttpd";
        const NGINX_TXT_NAME = "Nginx";
        const APACHE_TXT_NAME = "Apache";
        
		function getServerType() {
			$serverSoftware = $_SERVER['SERVER_SOFTWARE'] ?? '';

			if (!$serverSoftware) {
				return null;
			}

			if (stripos($serverSoftware, 'lighttpd') !== false) {
				return Server::LIGHTTPD;
			}

			if (stripos($serverSoftware, 'nginx') !== false) {
				return Server::NGINX;
			}

			if (stripos($serverSoftware, 'apache') !== false) {
				return Server::APACHE;
			}

			return null;
		}
        
        function getAuth() {
            $authInfo = array();
            $file_handle = false;

            $serverType = $this->getServerType();

            if ($serverType == Server::LIGHTTPD) { $file_handle = @fopen(Server::LIGHTTPD_FOLDER_PASS, "r"); }
            if ($serverType == Server::NGINX) { $file_handle = @fopen(Server::NGINX_FOLDER_PASS, "r"); }
            if ($serverType == Server::APACHE) { $file_handle = @fopen(Server::APACHE_FOLDER_PASS, "r"); }
            
            if ($file_handle) {
                while (!feof($file_handle)) {
                    $line = fgets($file_handle);
                    $array = array();
                    if ($serverType == Server::LIGHTTPD) { $array = explode(':', $line); }
                    if ($serverType == Server::NGINX) { $array = explode(':{PLAIN}', $line); }
                    if ($serverType == Server::APACHE) { $array = explode(':', $line); }
                    $authInfo["login"] = $array[0];
                    $authInfo["password"] = $array[1];
                    return $authInfo;
                }
            } else {
                return false;
            }
        }
        
        public static function getTextName($server) {
            $result = Server::LIGHTTPD_TXT_NAME;
            if ($server == Server::NGINX) $result = Server::NGINX_TXT_NAME;
            if ($server == Server::APACHE) $result = Server::APACHE_TXT_NAME;
            return $result;
        }

        function getServerInfoNginx() {
            $serverInfo = array();
            $authInfo = $this->getAuth();
            $context = stream_context_create(array(
                'http' => array(
                    'header' => "Authorization: Basic " . base64_encode($authInfo["login"] . ":" . $authInfo["password"])
                )
            ));
            $html = file_get_contents("http://" . str_replace("localhost", "127.0.0.1", $_SERVER["HTTP_HOST"]) . "/nginx_status", false, $context);
            $array = explode(' ', $html);
            $serverInfo["activeConnections"] = $array[2];
            $serverInfo["accepts"] = $array[7];
            $serverInfo["handled"] = $array[8];
            $serverInfo["requests"] = $array[9];
            $serverInfo["reading"] = $array[11];
            $serverInfo["writing"] = $array[13];
            $serverInfo["waiting"] = $array[15];
            return $serverInfo;
        }
    }