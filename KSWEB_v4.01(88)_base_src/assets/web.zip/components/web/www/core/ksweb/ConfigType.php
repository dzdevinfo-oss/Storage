<?php

    class ConfigType {
        const SERVER_LIGHTTPD = 1;
        const SERVER_NGINX = 2;
        const PHP = 3;
        const MYSQL = 4;
        const SERVER_APACHE = 5;
        const LIGHTTPD_HOST = 6;
        const NGINX_HOST = 7;
        const APACHE_HOST = 8;
    }