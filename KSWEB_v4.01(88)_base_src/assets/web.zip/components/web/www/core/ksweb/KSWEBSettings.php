<?php

class KSWEBSettings {
    const KSWEB_PREFERENCES_XML_CMD = "/data/data/ru.kslabs.ksweb/shared_prefs/ru.kslabs.ksweb_preferences.xml";
    
    function get() {
        $settings = array();
        $xml = file_get_contents(KSWEBSettings::KSWEB_PREFERENCES_XML_CMD);
        $dom = new DOMDocument;
        $dom->loadXML($xml);
        $map = $dom->getElementsByTagName('string');
        $map = $dom->getElementsByTagName('boolean');
        foreach($map as $m) {
            if ($m->getAttribute("name") == "enableStartMinimized") $settings["is_start_min"] = $m->getAttribute("value");
            if ($m->getAttribute("name") == "enableAutoStart") $settings["auto_start"] = $m->getAttribute("value");
            if ($m->getAttribute("name") == "externalINI") $settings["move_inis"] = $m->getAttribute("value");
            if ($m->getAttribute("name") == "allowRoot") $settings["enable_root_func"] = $m->getAttribute("value");
            if ($m->getAttribute("name") == "wifiLock") $settings["wifiLock"] = $m->getAttribute("value");
        }
        return $settings;
    }

    function set($key, $value) {
        $settingsFileName = KSWEBSettings::KSWEB_PREFERENCES_XML_CMD;
        $xml = file_get_contents($settingsFileName);
        $dom = new DOMDocument;
        $dom->formatOutput = true;
        $dom->loadXML($xml);
        $map = $dom->getElementsByTagName('string');
        foreach($map as $m) {
            if ($m->getAttribute("name") == $key) $m->nodeValue = $value;
        }

        $map = $dom->getElementsByTagName('boolean');
        foreach($map as $m) {
            if ($m->getAttribute("name") == $key) $m->setAttribute("value", $value);
        }

        unlink($settingsFileName);
        $dom->save($settingsFileName);
    }
}