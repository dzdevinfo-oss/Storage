<?php

class Url {
    private $actionStrFull;
    private $actionName = "";
    private $controllerName = "";
    
    public function __construct($action) {
        $this->actionStrFull = $action;
        
        $pieces = explode("/", (string)$this->actionStrFull);
        if (count($pieces) == 1) {
            $this->actionName = $pieces[0];
        } elseif (count($pieces) == 2) {
            $this->controllerName = $pieces[0];
            $this->action = $pieces[1];
        }
		
		$this->controllerName = preg_replace('/[^a-zA-Z0-9]/', '', $this->controllerName);
        $this->actionName = preg_replace('/[^a-zA-Z0-9]/', '', $this->actionName);
    }
    
    function getControllerName() {
        return $this->controllerName;
    }
    
    function getActionName() {
        return $this->actionName;
    }

    function getCurrentAddress() {
        $address = "?action=index";
        if ($this->getControllerName() != "") {
            if ($this->getActionName() != "") {
                $address = "?action=".$this->getControllerName()."/".$this->getActionName();
            } else {
                $address = "?action=".$this->getControllerName()."/index";
            }
        } else {
            if ($this->getActionName() != "") {
                $address = "?action=".$this->getActionName();
            }
        }
        return $address;
    }
    
    static function goToIndex() {
        header("Location: /");
    }

    function isThisCurrentPage($address) {
        if ($address == '/') {
            if ($this->controllerName == "") {
                if ($this->actionName == "index") return true;
            }
        }
        
        $pieces = explode("/", $address);
        if (count($pieces) == 1) {
            if ($this->controllerName == "") {
                if ($this->actionName == $pieces[0]) return true;
            }
        } elseif (count($pieces) == 2) {
            if ($this->controllerName == $pieces[0] && $this->actionName == $pieces[1]) return true;
        }
        return false;
    }
}