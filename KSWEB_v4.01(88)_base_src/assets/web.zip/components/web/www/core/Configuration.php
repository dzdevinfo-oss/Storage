<?php

class Configuration {
    private $jsScripts = array();
    private $cssStyles = array();
    
    function addJS($jsScript) {
        array_push($this->jsScripts, $jsScript);
    }
    function addCSS($cssStyle) {
        array_push($this->cssStyles, $cssStyle);
    }
    
    function getJSSctipts() {
        return $this->jsScripts;
    }
    function getCSSStyles() {
        return $this->cssStyles;
    }
}