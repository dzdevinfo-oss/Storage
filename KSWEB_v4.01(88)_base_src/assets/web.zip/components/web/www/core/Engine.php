<?php

spl_autoload_register('Engine::classLoader');

class Engine {
	
	private const VERSION = "3.1";
	
    private $coreController;
    private $url;
    
    public function __construct() {
        $this->coreController = new CoreController($this);
    }
    
    public static function classLoader($className) {
        if (file_exists('core/'.$className.".php")) {
            require_once('core/'.$className.".php");
        }
        if (file_exists('controller/'.$className.".php")) {
            require_once('controller/'.$className.".php");
        }
        if (file_exists('core/ksweb/'.$className.".php")) {
            require_once('core/ksweb/'.$className.".php");
        }
    }
    
    function getCoreController() {
        return $this->coreController;
    }

    /**
     * @return Url
     */
    function getUrl() {
        return $this->url;
    }
    
    function start() {
        $activeController = new Site($this);
        
        $action = filter_input(INPUT_GET, 'action');
        
        $this->url = new Url($action);

        $controllerName = $this->url->getControllerName();
        if ($controllerName != "") {
            if (class_exists(ucfirst($controllerName))) {
                $activeController = new $controllerName($this);
            } else {
                $this->coreController->actionError404();
            }
        }
        
        $actionName = $this->url->getActionName();
        if ($actionName != "") {
            if (method_exists($activeController, "action".ucfirst($actionName))) {
                $activeController->{"action".ucfirst($actionName)}();
            } else {
                $this->coreController->actionError404();
            }
        } else {
            $activeController->actionIndex();
        }
    }
	
	function getVersion() {
		return Engine::VERSION;
	}
}