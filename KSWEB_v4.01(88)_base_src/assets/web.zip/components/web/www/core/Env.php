<?php

class Env {
    /**
     * @var Engine
     */
    var $engine ;
    public function __construct($engine) {
        $this->engine = $engine;
    }
}