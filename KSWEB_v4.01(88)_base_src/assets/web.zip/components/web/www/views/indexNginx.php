<?
    $serverInfo = $this->params["serverInfo"];
?>
<div class="container">
    <div class="row">
        <div class="col s12 m12 l12">
            <div class="card white" style="overflow-y: scroll">
                <div class="card-content grey-text text-darken-3">
                    <span class="card-title">General statistic</span>


                    <table class="striped">
                        <thead>
                        <tr>
                            <th colspan="2" class="center-align">
                                <svg style="width:50px;height:50px" viewBox="0 0 24 24">
                                    <path fill="#424242" d="M4,1H20A1,1 0 0,1 21,2V6A1,1 0 0,1 20,7H4A1,1 0 0,1 3,6V2A1,1 0 0,1 4,1M4,9H20A1,1 0 0,1 21,10V14A1,1 0 0,1 20,15H4A1,1 0 0,1 3,14V10A1,1 0 0,1 4,9M4,17H20A1,1 0 0,1 21,18V22A1,1 0 0,1 20,23H4A1,1 0 0,1 3,22V18A1,1 0 0,1 4,17M9,5H10V3H9V5M9,13H10V11H9V13M9,21H10V19H9V21M5,3V5H7V3H5M5,11V13H7V11H5M5,19V21H7V19H5Z" />
                                </svg>
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td class="center-align"><b>Active connections: </b> <?php echo htmlspecialchars($serverInfo["activeConnections"], ENT_QUOTES, 'UTF-8'); ?></td>
                        </tr>
                        <tr>
                            <td class="center-align"><b>Accepted connections: </b><?php echo htmlspecialchars($serverInfo["accepts"], ENT_QUOTES, 'UTF-8'); ?></td>
                        </tr>
                        <tr>
                            <td class="center-align"><b>Handled connections: </b> <?php echo htmlspecialchars($serverInfo["handled"], ENT_QUOTES, 'UTF-8'); ?></td>
                        </tr>
                        <tr>
                            <td class="center-align"><b>Handled requests: </b><?php echo htmlspecialchars($serverInfo["requests"], ENT_QUOTES, 'UTF-8'); ?></td>
                        </tr>
                        <tr>
                            <td class="center-align"><b>Read request headers: </b><?php echo htmlspecialchars($serverInfo["reading"], ENT_QUOTES, 'UTF-8'); ?></td>
                        </tr>
                        <tr>
                            <td class="center-align"><b>Wrote responses: </b><?php echo htmlspecialchars($serverInfo["writing"], ENT_QUOTES, 'UTF-8'); ?></td>
                        </tr>
                        <tr>
                            <td class="center-align"><b>Keep-alive connections : </b><?php echo htmlspecialchars($serverInfo["waiting"], ENT_QUOTES, 'UTF-8'); ?></td>
                        </tr>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>