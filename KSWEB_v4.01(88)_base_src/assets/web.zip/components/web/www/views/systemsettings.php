<script type="text/javascript">
    $(document).ready(function() {
        $("#yes_button").click(function(){
            var current_password = $.base64.encode($('#current_password').val());
            var new_password = $.base64.encode($('#new_password').val());
            var confirm_password = $.base64.encode($('#confirm_password').val());

            $('#result').css('display', 'none');
            $.post('?action=savesystemsettings', {current_password: current_password, new_password: new_password, confirm_password: confirm_password}, function(data) {
                Materialize.toast(data, 4000);
            });
        });
    });
</script>
<div class="container">
    <div class="row">
        <div class="col s12 m12 l12">
            <div id="result" style="display:none;"></div>
            <div class="card white">
                <div class="card-content grey-text text-darken-3">
                    <span class="card-title">Administrator password</span>

                    <div class="row">
                        <div class="input-field col s12">
                            <input id="current_password" type="password" class="validate">
                            <label for="current_password">Current password</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s12">
                            <input id="new_password" type="password" class="validate">
                            <label for="new_password">New password</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s12">
                            <input id="confirm_password" type="password" class="validate">
                            <label for="confirm_password">Confirm password</label>
                        </div>
                    </div>
                </div>
                <div class="card-action">
                    <a class="linker blue-text" id="yes_button">Save</a>
                </div>
            </div>
        </div>
    </div>
</div>