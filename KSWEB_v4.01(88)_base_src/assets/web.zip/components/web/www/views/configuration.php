<?php
    $hostname = filter_input(INPUT_GET, 'hostname');
    $configType = filter_input(INPUT_GET, 'configType');
    
    if (!isset($configType)) {
        $configType = ConfigType::SERVER_LIGHTTPD;
    }
    $engine = $this->params['engine'];
    
    $config = new Config($configType, $engine);
 
    if ($hostname != "") {
        $config = new Config($configType, $engine, $hostname);
    }
       
    ?>

    <link href="web/css/codemirror.css" rel="stylesheet">
    <script src="web/js/codemirror.js"></script>
    <script src="web/js/properties.js"></script>
    
    <style>
        .CodeMirror {
            border: 1px solid #f7f7f7;
            background: #f7f7f7;
            height: auto;
        }
        .CodeMirror-gutters {
            background-color: #eee;
        }
    </style>


<? if ($configType != ConfigType::PHP && $configType != ConfigType::MYSQL) { ?>
        <div class="container" style = "margin-top: 10px">
            <div class="row">
                <div class="col s12 m12 l12">
                    <div class="card">
                        <div class="card-content">
                            <p><?php
                                $hostListTxt = $config->getHostListTxt();
                                if ($hostListTxt != "") {
                                    echo $hostListTxt;
                                } else {
                                    echo "Server has no active hosts";
                                }
                                ?></p>
                        </div>
                        <div class="card-action">
                            <a href="<?= $engine->getUrl()->getCurrentAddress() . "&configType=" . ConfigType::SERVER_LIGHTTPD ?>">Lighttpd</a>
                            <a href="<?= $engine->getUrl()->getCurrentAddress() . "&configType=" . ConfigType::SERVER_NGINX ?>">Nginx</a>
                            <a href="<?= $engine->getUrl()->getCurrentAddress() . "&configType=" . ConfigType::SERVER_APACHE ?>">Apache</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<? } ?>

    <div class="container">
        <div class="row">
            <div class="col s12 m12 l12">
                <div id="result" class="card-panel darken-1 white-text" style="display: none;"></div>
            </div>
        </div>
    </div>

    <main>
        <div class="container">
            <div class="row">
                <div class="col s12 m12 l12">
                    <div class="card white">
                        <div class="card-content grey-text text-darken-3">
                            <p>
                                <? if (file_exists($config->getConfigFullPath())) { ?>
                                
                                <span class="card-title">Text Editor</span>
                                <div class="right-align" style="margin-top: -45px;">
                                    <a id="save-config" onclick="return false;"
                                       class="btn-floating waves-effect waves-light-grey white" style="box-shadow:none;"><i
                                                class="material-icons grey-text text-darken-3">&#xE161;</i></a>
                                </div>
                                <div class="input-field">
                                    <textarea id="config-file-content"><?= $config->getConfigFileContent() ?></textarea>
                                    <label style="padding-bottom:4px;" for="config-file-content"><?= htmlspecialchars($config->getConfigFullPath(), ENT_QUOTES, 'UTF-8') ?></label>
                                </div>
                             <? } else { ?>
                                <script>
                                    var fileName = '<?= addslashes(htmlspecialchars($configFile ?? '', ENT_QUOTES, 'UTF-8')) ?>';
									$('#result').text('File \'' + fileName + '\' not found!');
                                    $('#result').removeClass('card-panel green darken-1 white-text');
                                    $('#result').addClass('card-panel red darken-1 white-text').fadeIn(1500).delay(5000).fadeOut(1500);
                                </script>";
                                <?}?>
                            </p>
                        </div>
                    </div>
                </div>
                </div>
        </div>
    </main>
    <script type='text/javascript'>
        var editor = CodeMirror.fromTextArea(document.getElementById("config-file-content"), {
            mode: "properties",
            lineNumbers: true,
            lineWrapping: true,
            viewportMargin: Infinity,
        });
        
        $(document).ready(function () {
            $("#save-config").click(function () {
                $('#result').css('display', 'none');
                $.post('?action=savesettings', {
                    configType: '<?= $configType; ?>',
                    hostname: '<?= $hostname; ?>',
                    content: editor.getValue()
                }, function (data) {
                    var obj = jQuery.parseJSON(data);
                    if (obj.saved) {
                        $('#result').html("<h5>Success</h5>" + obj.message);
                        $('#result').removeClass('card-panel red darken-1 white-text');
                        $('#result').addClass('card-panel green darken-1 white-text').fadeIn(1500).delay(5000).fadeOut(1500);
                    } else {
                        $('#result').html("<h5>Error</h5>" + obj.message);
                        $('#result').removeClass('card-panel green darken-1 white-text');
                        $('#result').addClass('card-panel red darken-1 white-text').fadeIn(1500).delay(5000).fadeOut(1500);
                    }
                });
            });
        });
    </script>