<main>
    <div class="container">
        <div class="row">
            <div class="col s12 m12 l12">
                <div class="card white" style="overflow-y: scroll">
                    <div class="card-content grey-text text-darken-3">
                        <p>
<?= $this->params['html']; ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>