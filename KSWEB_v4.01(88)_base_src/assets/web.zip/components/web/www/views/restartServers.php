<script type="text/javascript">
    $(document).ready(function() {
        $("#do_restart_button").click(function(){
            $('#tootip').css('display', 'none');
            $.post('?action=Requestrestartservers', {}, function(data) {
                Materialize.toast(data, 4000);
            });
        });
        $("#go_back_button").click(function(){
            document.location.href = "/";
        });
    });
</script>
<div class="container">
    <div class="row">
        <div class="col s12 m12 l12">
            <div id="tootip" style="display:none;"></div>
            <div class="card white">
                <div class="card-content grey-text text-darken-3">
                    <span class="card-title">Restart KSWEB</span><br>
                    <b>You should know the following before you restart the server:</b><br><br>
                    The errors in config files of the server, PHP or MySQL can lead that they did not start again. In this case you can't use KSWEB Web Interface until you correct the errors.<br><br>
                    The server will be restarted only in case if KSWEB service is started on your Android device.<br><br>
                    You may need to confirm using root rights on the device in case "root functions" was enabled.
                </div>
                <div class="card-action">
                    <a class="linker blue-text nos" id="go_back_button">No</a>
                    <a class="linker blue-text nos" id="do_restart_button">Yes, Restart Now</a>
                </div>
            </div>
        </div>
    </div>
</div>