/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

import { Codicon } from '../../../../base/common/codicons.js';
import type { IStringDictionary } from '../../../../base/common/collections.js';
import { IJSONSchemaSnippet } from '../../../../base/common/jsonSchema.js';
import { isMacintosh, isWindows } from '../../../../base/common/platform.js';
import { isString } from '../../../../base/common/types.js';
import { localize } from '../../../../nls.js';
import { ConfigurationScope, Extensions, IConfigurationRegistry, type IConfigurationPropertySchema } from '../../../../platform/configuration/common/configurationRegistry.js';
import product from '../../../../platform/product/common/product.js';
import { Registry } from '../../../../platform/registry/common/platform.js';
import { TerminalLocationConfigValue, TerminalSettingId } from '../../../../platform/terminal/common/terminal.js';
import { terminalColorSchema, terminalIconSchema } from '../../../../platform/terminal/common/terminalPlatformConfiguration.js';
import { ConfigurationKeyValuePairs, IConfigurationMigrationRegistry, Extensions as WorkbenchExtensions } from '../../../common/configuration.js';
import { terminalContribConfiguration, TerminalContribSettingId } from '../terminalContribExports.js';
import { DEFAULT_COMMANDS_TO_SKIP_SHELL, DEFAULT_LETTER_SPACING, DEFAULT_LINE_HEIGHT, MAXIMUM_FONT_WEIGHT, MINIMUM_FONT_WEIGHT, SUGGESTIONS_FONT_WEIGHT } from './terminal.js';

const terminalDescriptors = '\n- ' + [
	'`\${cwd}`: ' + localize("cwd", "the terminal's current working directory."),
	'`\${cwdFolder}`: ' + localize('cwdFolder', "the terminal's current working directory, displayed for multi-root workspaces or in a single root workspace when the value differs from the initial working directory. On Windows, this will only be displayed when shell integration is enabled."),
	'`\${workspaceFolder}`: ' + localize('workspaceFolder', "the workspace in which the terminal was launched."),
	'`\${workspaceFolderName}`: ' + localize('workspaceFolderName', "the `name` of the workspace in which the terminal was launched."),
	'`\${local}`: ' + localize('local', "indicates a local terminal in a remote workspace."),
	'`\${process}`: ' + localize('process', "the name of the terminal process."),
	'`\${progress}`: ' + localize('progress', "the progress state as reported by the `OSC 9;4` sequence."),
	'`\${separator}`: ' + localize('separator', "a conditional separator {0} that only shows when it's surrounded by variables with values or static text.", '(` - `)'),
	'`\${sequence}`: ' + localize('sequence', "the name provided to the terminal by the process."),
	'`\${task}`: ' + localize('task', "indicates this terminal is associated with a task."),
	'`\${shellType}`: ' + localize('shellType', "the detected shell type."),
	'`\${shellCommand}`: ' + localize('shellCommand', "the command being executed according to shell integration. This also requires high confidence in the detected command line, which may not work in some prompt frameworks."),
	'`\${shellPromptInput}`: ' + localize('shellPromptInput', "the shell's full prompt input according to shell integration."),
].join('\n- '); // intentionally concatenated to not produce a string that is too long for translations

let terminalTitle = localize('terminalTitle', "Controls the terminal title. Variables are substituted based on the context:");
terminalTitle += terminalDescriptors;

let terminalDescription = localize('terminalDescription', "Controls the terminal description, which appears to the right of the title. Variables are substituted based on the context:");
terminalDescription += terminalDescriptors;

export const defaultTerminalFontSize = isMacintosh ? 12 : 14;

const terminalConfiguration: IStringDictionary<IConfigurationPropertySchema> = {
	[TerminalSettingId.SendKeybindingsToShell]: {
		markdownDescription: localize('terminal.integrated.sendKeybindingsToShell', "Dispatches most keybindings to the terminal instead of the workbench, overriding {0}, which can be used alternatively for fine tuning.", '`#terminal.integrated.commandsToSkipShell#`'),
		type: 'boolean',
		default: false
	},
	[TerminalSettingId.TabsDefaultColor]: {
		description: localize('terminal.integrated.tabs.defaultColor', "A theme color ID to associate with terminal icons by default."),
		...terminalColorSchema,
		scope: ConfigurationScope.RESOURCE
	},
	[TerminalSettingId.TabsDefaultIcon]: {
		description: localize('terminal.integrated.tabs.defaultIcon', "A codicon ID to associate with terminal icons by default."),
		...terminalIconSchema,
		default: Codicon.terminal.id,
		scope: ConfigurationScope.RESOURCE
	},
	[TerminalSettingId.TabsEnabled]: {
		description: localize('terminal.integrated.tabs.enabled', 'Controls whether terminal tabs display as a list to the side of the terminal. When this is disabled a dropdown will display instead.'),
		type: 'boolean',
		default: true,
	},
	[TerminalSettingId.TabsEnableAnimation]: {
		description: localize('terminal.integrated.tabs.enableAnimation', 'Controls whether terminal tab statuses support animation (eg. in progress tasks).'),
		type: 'boolean',
		default: true,
	},
	[TerminalSettingId.TabsHideCondition]: {
		description: localize('terminal.integrated.tabs.hideCondition', 'Controls whether the terminal tabs view will hide under certain conditions.'),
		type: 'string',
		enum: ['never', 'singleTerminal', 'singleGroup'],
		enumDescriptions: [
			localize('terminal.integrated.tabs.hideCondition.never', "Never hide the terminal tabs view"),
			localize('terminal.integrated.tabs.hideCondition.singleTerminal', "Hide the terminal tabs view when there is only a single terminal opened"),
			localize('terminal.integrated.tabs.hideCondition.singleGroup', "Hide the terminal tabs view when there is only a single terminal group opened"),
		],
		default: 'singleTerminal',
	},
	[TerminalSettingId.TabsShowActiveTerminal]: {
		description: localize('terminal.integrated.tabs.showActiveTerminal', 'Shows the active terminal information in the view. This is particularly useful when the title within the tabs aren\'t visible.'),
		type: 'string',
		enum: ['always', 'singleTerminal', 'singleTerminalOrNarrow', 'never'],
		enumDescriptions: [
			localize('terminal.integrated.tabs.showActiveTerminal.always', "Always show the active terminal"),
			localize('terminal.integrated.tabs.showActiveTerminal.singleTerminal', "Show the active terminal when it is the only terminal opened"),
			localize('terminal.integrated.tabs.showActiveTerminal.singleTerminalOrNarrow', "Show the active terminal when it is the only terminal opened or when the tabs view is in its narrow textless state"),
			localize('terminal.integrated.tabs.showActiveTerminal.never', "Never show the active terminal"),
		],
		default: 'singleTerminalOrNarrow',
	},
	[TerminalSettingId.TabsShowActions]: {
		description: localize('terminal.integrated.tabs.showActions', 'Controls whether terminal split and kill buttons are displays next to the new terminal button.'),
		type: 'string',
		enum: ['always', 'singleTerminal', 'singleTerminalOrNarrow', 'never'],
		enumDescriptions: [
			localize('terminal.integrated.tabs.showActions.always', "Always show the actions"),
			localize('terminal.integrated.tabs.showActions.singleTerminal', "Show the actions when it is the only terminal opened"),
			localize('terminal.integrated.tabs.showActions.singleTerminalOrNarrow', "Show the actions when it is the only terminal opened or when the tabs view is in its narrow textless state"),
			localize('terminal.integrated.tabs.showActions.never', "Never show the actions"),
		],
		default: 'singleTerminalOrNarrow',
	},
	[TerminalSettingId.TabsLocation]: {
		type: 'string',
		enum: ['left', 'right'],
		enumDescriptions: [
			localize('terminal.integrated.tabs.location.left', "Show the terminal tabs view to the left of the terminal"),
			localize('terminal.integrated.tabs.location.right', "Show the terminal tabs view to the right of the terminal")
		],
		default: 'right',
		description: localize('terminal.integrated.tabs.location', "Controls the location of the terminal tabs, either to the left or right of the actual terminal(s).")
	},
	[TerminalSettingId.DefaultLocation]: {
		type: 'string',
		enum: [TerminalLocationConfigValue.Editor, TerminalLocationConfigValue.TerminalView],
		enumDescriptions: [
			localize('terminal.integrated.defaultLocation.editor', "Create terminals in the editor"),
			localize('terminal.integrated.defaultLocation.view', "Create terminals in the terminal view")
		],
		default: 'view',
		description: localize('terminal.integrated.defaultLocation', "Controls where newly created terminals will appear.")
	},
	[TerminalSettingId.TabsFocusMode]: {
		type: 'string',
		enum: ['singleClick', 'doubleClick'],
		enumDescriptions: [
			localize('terminal.integrated.tabs.focusMode.singleClick', "Focus the terminal when clicking a terminal tab"),
			localize('terminal.integrated.tabs.focusMode.doubleClick', "Focus the terminal when double-clicking a terminal tab")
		],
		default: 'doubleClick',
		description: localize('terminal.integrated.tabs.focusMode', "Controls whether focusing the terminal of a tab happens on double or single click.")
	},
	[TerminalSettingId.TabsAllowAgentCliTitle]: {
		description: localize('terminal.integrated.tabs.allowAgentCliTitle', "Controls whether agentic CLIs (such as Claude Code, Codex, GitHub Copilot CLI, and Gemini CLI) are allowed to set the terminal tab title via escape sequences. When disabled, the configured tab title template is used instead."),
		type: 'boolean',
		default: true,
	},
	[TerminalSettingId.MacOptionIsMeta]: {
		description: localize('terminal.integrated.macOptionIsMeta', "Controls whether to treat the option key as the meta key in the terminal on macOS."),
		type: 'boolean',
		default: false
	},
	[TerminalSettingId.MacOptionClickForcesSelection]: {
		description: localize('terminal.integrated.macOptionClickForcesSelection', "Controls whether to force selection when using Option+click on macOS. This will force a regular (line) selection and disallow the use of column selection mode. This enables copying and pasting using the regular terminal selection, for example, when mouse mode is enabled in tmux."),
		type: 'boolean',
		default: false
	},
	[TerminalSettingId.AltClickMovesCursor]: {
		markdownDescription: localize('terminal.integrated.altClickMovesCursor', "If enabled, alt/option + click will reposition the prompt cursor to underneath the mouse when {0} is set to {1} (the default value). This may not work reliably depending on your shell.", '`#editor.multiCursorModifier#`', '`\'alt\'`'),
		type: 'boolean',
		default: true
	},
	[TerminalSettingId.CopyOnSelection]: {
		description: localize('terminal.integrated.copyOnSelection', "Controls whether text selected in the terminal will be copied to the clipboard."),
		type: 'boolean',
		default: false
	},
	[TerminalSettingId.EnableMultiLinePasteWarning]: {
		markdownDescription: localize('terminal.integrated.enableMultiLinePasteWarning', "Controls whether to show a warning dialog when pasting multiple lines into the terminal."),
		type: 'string',
		enum: ['auto', 'always', 'never'],
		markdownEnumDescriptions: [
			localize('terminal.integrated.enableMultiLinePasteWarning.auto', "Enable the warning but do not show it when:\n\n- Bracketed paste mode is enabled (the shell supports multi-line paste natively)\n- The paste is handled by the shell's readline (in the case of pwsh)"),
			localize('terminal.integrated.enableMultiLinePasteWarning.always', "Always show the warning if the text contains a new line."),
			localize('terminal.integrated.enableMultiLinePasteWarning.never', "Never show the warning.")
		],
		default: 'auto'
	},
	[TerminalSettingId.DrawBoldTextInBrightColors]: {
		description: localize('terminal.integrated.drawBoldTextInBrightColors', "Controls whether bold text in the terminal will always use the \"bright\" ANSI color variant."),
		type: 'boolean',
		default: true
	},
	[TerminalSettingId.FontFamily]: {
		markdownDescription: localize('terminal.integrated.fontFamily', "Controls the font family of the terminal. Defaults to {0}'s value.", '`#editor.fontFamily#`'),
		type: 'string',
	},
	[TerminalSettingId.FontLigaturesEnabled]: {
		markdownDescription: localize('terminal.integrated.fontLigatures.enabled', "Controls whether font ligatures are enabled in the terminal. Ligatures will only work if the configured {0} supports them.", `\`#${TerminalSettingId.FontFamily}#\``),
		type: 'boolean',
		default: false
	},
	[TerminalSettingId.FontLigaturesFeatureSettings]: {
		markdownDescription: localize('terminal.integrated.fontLigatures.featureSettings', "Controls what font feature settings are used when ligatures are enabled, in the format of the `font-feature-settings` CSS property. Some examples which may be valid depending on the font:") + '\n\n- ' + [
			`\`"calt" off, "ss03"\``,
			`\`"liga" on\``,
			`\`"calt" off, "dlig" on\``
		].join('\n- '),
		type: 'string',
		default: '"calt" on'
	},
	[TerminalSettingId.FontLigaturesFallbackLigatures]: {
		markdownDescription: localize('terminal.integrated.fontLigatures.fallbackLigatures', "When {0} is enabled and the particular {1} cannot be parsed, this is the set of character sequences that will always be drawn together. This allows the use of a fixed set of ligatures even when the font isn't supported.", `\`#${TerminalSettingId.GpuAcceleration}#\``, `\`#${TerminalSettingId.FontFamily}#\``),
		type: 'array',
		items: [{ type: 'string' }],
		default: [
			'<--', '<---', '<<-', '<-', '->', '->>', '-->', '--->',
			'<==', '<===', '<<=', '<=', '=>', '=>>', '==>', '===>', '>=', '>>=',
			'<->', '<-->', '<--->', '<---->', '<=>', '<==>', '<===>', '<====>', '::', ':::',
			'<~~', '</', '</>', '/>', '~~>', '==', '!=', '/=', '~=', '<>', '===', '!==', '!===',
			'<:', ':=', '*=', '*+', '<*', '<*>', '*>', '<|', '<|>', '|>', '+*', '=*', '=:', ':>',
			'/*', '*/', '+++', '<!--', '<!---'
		]
	},
	[TerminalSettingId.FontSize]: {
		description: localize('terminal.integrated.fontSize', "Controls the font size in pixels of the terminal."),
		type: 'number',
		default: defaultTerminalFontSize,
		minimum: 6,
		maximum: 100
	},
	[TerminalSettingId.LetterSpacing]: {
		description: localize('terminal.integrated.letterSpacing', "Controls the letter spacing of the terminal. This is an integer value which represents the number of additional pixels to add between characters."),
		type: 'number',
		default: DEFAULT_LETTER_SPACING
	},
	[TerminalSettingId.LineHeight]: {
		description: localize('terminal.integrated.lineHeight', "Controls the line height of the terminal. This number is multiplied by the terminal font size to get the actual line-height in pixels."),
		type: 'number',
		default: DEFAULT_LINE_HEIGHT
	},
	[TerminalSettingId.MinimumContrastRatio]: {
		markdownDescription: localize('terminal.integrated.minimumContrastRatio', "When set, the foreground color of each cell will change to try meet the contrast ratio specified. Note that this will not apply to `powerline` characters per #146406. Example values:\n\n- 1: Do nothing and use the standard theme colors.\n- 4.5: [WCAG AA compliance (minimum)](https://www.w3.org/TR/UNDERSTANDING-WCAG20/visual-audio-contrast-contrast.html) (default).\n- 7: [WCAG AAA compliance (enhanced)](https://www.w3.org/TR/UNDERSTANDING-WCAG20/visual-audio-contrast7.html).\n- 21: White on black or black on white."),
		type: 'number',
		default: 4.5,
		tags: ['accessibility']
	},
	[TerminalSettingId.TabStopWidth]: {
		markdownDescription: localize('terminal.integrated.tabStopWidth', "The number of cells in a tab stop."),
		type: 'number',
		minimum: 1,
		default: 8
	},
	[TerminalSettingId.FastScrollSensitivity]: {
		markdownDescription: localize('terminal.integrated.fastScrollSensitivity', "Scrolling speed multiplier when pressing `Alt`."),
		type: 'number',
		default: 5
	},
	[TerminalSettingId.MouseWheelScrollSensitivity]: {
		markdownDescription: localize('terminal.integrated.mouseWheelScrollSensitivity', "A multiplier to be used on the `deltaY` of mouse wheel scroll events."),
		type: 'number',
		default: 1
	},
	[TerminalSettingId.BellDuration]: {
		markdownDescription: localize('terminal.integrated.bellDuration', "The number of milliseconds to show the bell within a terminal tab when triggered."),
		type: 'number',
		default: 1000
	},
	[TerminalSettingId.FontWeight]: {
		'anyOf': [
			{
				type: 'number',
				minimum: MINIMUM_FONT_WEIGHT,
				maximum: MAXIMUM_FONT_WEIGHT,
				errorMessage: localize('terminal.integrated.fontWeightError', "Only \"normal\" and \"bold\" keywords or numbers between 1 and 1000 are allowed.")
			},
			{
				type: 'string',
				pattern: '^(normal|bold|1000|[1-9][0-9]{0,2})$'
			},
			{
				enum: SUGGESTIONS_FONT_WEIGHT,
			}
		],
		description: localize('terminal.integrated.fontWeight', "The font weight to use within the terminal for non-bold text. Accepts \"normal\" and \"bold\" keywords or numbers between 1 and 1000."),
		default: 'normal'
	},
	[TerminalSettingId.FontWeightBold]: {
		'anyOf': [
			{
				type: 'number',
				minimum: MINIMUM_FONT_WEIGHT,
				maximum: MAXIMUM_FONT_WEIGHT,
				errorMessage: localize('terminal.integrated.fontWeightError', "Only \"normal\" and \"bold\" keywords or numbers between 1 and 1000 are allowed.")
			},
			{
				type: 'string',
				pattern: '^(normal|bold|1000|[1-9][0-9]{0,2})$'
			},
			{
				enum: SUGGESTIONS_FONT_WEIGHT,
			}
		],
		description: localize('terminal.integrated.fontWeightBold', "The font weight to use within the terminal for bold text. Accepts \"normal\" and \"bold\" keywords or numbers between 1 and 1000."),
		default: 'bold'
	},
	[TerminalSettingId.CursorBlinking]: {
		description: localize('terminal.integrated.cursorBlinking', "Controls whether the terminal cursor blinks."),
		type: 'boolean',
		default: false
	},
	[TerminalSettingId.TextBlinking]: {
		description: localize('terminal.integrated.textBlinking', "Controls whether text blinking is enabled in the terminal."),
		type: 'boolean',
		default: false
	},
	[TerminalSettingId.CursorStyle]: {
		description: localize('terminal.integrated.cursorStyle', "Controls the style of terminal cursor when the terminal is focused."),
		enum: ['block', 'line', 'underline'],
		default: 'block'
	},
	[TerminalSettingId.CursorStyleInactive]: {
		description: localize('terminal.integrated.cursorStyleInactive', "Controls the style of terminal cursor when the terminal is not focused."),
		enum: ['outline', 'block', 'line', 'underline', 'none'],
		default: 'outline'
	},
	[TerminalSettingId.CursorWidth]: {
		markdownDescription: localize('terminal.integrated.cursorWidth', "Controls the width of the cursor when {0} is set to {1}.", '`#terminal.integrated.cursorStyle#`', '`line`'),
		type: 'number',
		default: 1
	},
	[TerminalSettingId.Scrollback]: {
		description: localize('terminal.integrated.scrollback', "Controls the maximum number of lines the terminal keeps in its buffer. We pre-allocate memory based on this value in order to ensure a smooth experience. As such, as the value increases, so will the amount of memory."),
		type: 'number',
		default: 1000
	},
	[TerminalSettingId.DetectLocale]: {
		markdownDescription: localize('terminal.integrated.detectLocale', "Controls whether to detect and set the `$LANG` environment variable to a UTF-8 compliant option since VS Code's terminal only supports UTF-8 encoded data coming from the shell."),
		type: 'string',
		enum: ['auto', 'off', 'on'],
		markdownEnumDescriptions: [
			localize('terminal.integrated.detectLocale.auto', "Set the `$LANG` environment variable if the existing variable does not exist or it does not end in `'.UTF-8'`."),
			localize('terminal.integrated.detectLocale.off', "Do not set the `$LANG` environment variable."),
			localize('terminal.integrated.detectLocale.on', "Always set the `$LANG` environment variable.")
		],
		default: 'auto'
	},
	[TerminalSettingId.GpuAcceleration]: {
		type: 'string',
		enum: ['auto', 'on', 'off'],
		markdownEnumDescriptions: [
			localize('terminal.integrated.gpuAcceleration.auto', "Let VS Code detect which renderer will give the best experience."),
			localize('terminal.integrated.gpuAcceleration.on', "Enable GPU acceleration within the terminal."),
			localize('terminal.integrated.gpuAcceleration.off', "Disable GPU acceleration within the terminal. The terminal will render much slower when GPU acceleration is off but it should reliably work on all systems."),
		],
		default: 'auto',
		description: localize('terminal.integrated.gpuAcceleration', "Controls whether the terminal will leverage the GPU to do its rendering.")
	},
	[TerminalSettingId.TerminalTitleSeparator]: {
		'type': 'string',
		'default': ' - ',
		'markdownDescription': localize("terminal.integrated.tabs.separator", "Separator used by {0} and {1}.", `\`#${TerminalSettingId.TerminalTitle}#\``, `\`#${TerminalSettingId.TerminalDescription}#\``)
	},
	[TerminalSettingId.TerminalTitle]: {
		'type': 'string',
		'default': '${process}',
		'markdownDescription': terminalTitle
	},
	[TerminalSettingId.TerminalDescription]: {
		'type': 'string',
		'default': '${task}${separator}${local}${separator}${cwdFolder}',
		'markdownDescription': terminalDescription
	},
	[TerminalSettingId.RightClickBehavior]: {
		type: 'string',
		enum: ['default', 'copyPaste', 'paste', 'selectWord', 'nothing'],
		enumDescriptions: [
			localize('terminal.integrated.rightClickBehavior.default', "Show the context menu."),
			localize('terminal.integrated.rightClickBehavior.copyPaste', "Copy when there is a selection, otherwise paste."),
			localize('terminal.integrated.rightClickBehavior.paste', "Paste on right click."),
			localize('terminal.integrated.rightClickBehavior.selectWord', "Select the word under the cursor and show the context menu."),
			localize('terminal.integrated.rightClickBehavior.nothing', "Do nothing and pass event to terminal.")
		],
		default: isMacintosh ? 'selectWord' : isWindows ? 'copyPaste' : 'default',
		description: localize('terminal.integrated.rightClickBehavior', "Controls how terminal reacts to right click.")
	},
	[TerminalSettingId.MiddleClickBehavior]: {
		type: 'string',
		enum: ['default', 'paste'],
		enumDescriptions: [
			localize('terminal.integrated.middleClickBehavior.default', "The platform default to focus the terminal. On Linux this will also paste the selection."),
			localize('terminal.integrated.middleClickBehavior.paste', "Paste on middle click."),
		],
		default: 'default',
		description: localize('terminal.integrated.middleClickBehavior', "Controls how terminal reacts to middle click.")
	},
	[TerminalSettingId.Cwd]: {
		restricted: true,
		description: localize('terminal.integrated.cwd', "An explicit start path where the terminal will be launched, this is used as the current working directory (cwd) for the shell process. This may be particularly useful in workspace settings if the root directory is not a convenient cwd."),
		type: 'string',
		default: undefined,
		scope: ConfigurationScope.RESOURCE
	},
	[TerminalSettingId.ConfirmOnExit]: {
		description: localize('terminal.integrated.confirmOnExit', "Controls whether to confirm when the window closes if there are active terminal sessions. Background terminals like those launched by some extensions will not trigger the confirmation."),
		type: 'string',
		enum: ['never', 'always', 'hasChildProcesses'],
		enumDescriptions: [
			localize('terminal.integrated.confirmOnExit.never', "Never confirm."),
			localize('terminal.integrated.confirmOnExit.always', "Always confirm if there are terminals."),
			localize('terminal.integrated.confirmOnExit.hasChildProcesses', "Confirm if there are any terminals that have child processes."),
		],
		default: 'never'
	},
	[TerminalSettingId.ConfirmOnKill]: {
		description: localize('terminal.integrated.confirmOnKill', "Controls whether to confirm killing terminals when they have child processes. When set to editor, terminals in the editor area will be marked as changed when they have child processes. Note that child process detection may not work well for shells like Git Bash which don't run their processes as child processes of the shell. Background terminals like those launched by some extensions will not trigger the confirmation."),
		type: 'string',
		enum: ['never', 'editor', 'panel', 'always'],
		enumDescriptions: [
			localize('terminal.integrated.confirmOnKill.never', "Never confirm."),
			localize('terminal.integrated.confirmOnKill.editor', "Confirm if the terminal is in the editor."),
			localize('terminal.integrated.confirmOnKill.panel', "Confirm if the terminal is in the panel."),
			localize('terminal.integrated.confirmOnKill.always', "Confirm if the terminal is either in the editor or panel."),
		],
		default: 'editor'
	},
	[TerminalSettingId.EnableBell]: {
		markdownDeprecationMessage: localize('terminal.integrated.enableBell', "This is now deprecated. Instead use the `terminal.integrated.enableVisualBell` and `accessibility.signals.terminalBell` settings."),
		type: 'boolean',
		default: false
	},
	[TerminalSettingId.EnableVisualBell]: {
		description: localize('terminal.integrated.enableVisualBell', "Controls whether the visual terminal bell is enabled. This shows up next to the terminal's name."),
		type: 'boolean',
		default: false
	},
	[TerminalSettingId.CommandsToSkipShell]: {
		markdownDescription: localize(
			'terminal.integrated.commandsToSkipShell',
			"A set of command IDs whose keybindings will not be sent to the shell but instead always be handled by VS Code. This allows keybindings that would normally be consumed by the shell to act instead the same as when the terminal is not focused, for example `Ctrl+P` to launch Quick Open.\n\n&nbsp;\n\nMany commands are skipped by default. To override a default and pass that command's keybinding to the shell instead, add the command prefixed with the `-` character. For example add `-workbench.action.quickOpen` to allow `Ctrl+P` to reach the shell.\n\n&nbsp;\n\nThe following list of default skipped commands is truncated when viewed in Settings Editor. To see the full list, {1} and search for the first command from the list below.\n\n&nbsp;\n\nDefault Skipped Commands:\n\n{0}",
			DEFAULT_COMMANDS_TO_SKIP_SHELL.sort().map(command => `- ${command}`).join('\n'),
			`[${localize('openDefaultSettingsJson', "open the default settings JSON")}](command:workbench.action.openRawDefaultSettings '${localize('openDefaultSettingsJson.capitalized', "Open Default Settings (JSON)")}')`,

		),
		type: 'array',
		items: {
			type: 'string'
		},
		default: []
	},
	[TerminalSettingId.AllowChords]: {
		markdownDescription: localize('terminal.integrated.allowChords', "Whether or not to allow chord keybindings in the terminal. Note that when this is true and the keystroke results in a chord it will bypass {0}, setting this to false is particularly useful when you want ctrl+k to go to your shell (not VS Code).", '`#terminal.integrated.commandsToSkipShell#`'),
		type: 'boolean',
		default: true
	},
	[TerminalSettingId.AllowMnemonics]: {
		markdownDescription: localize('terminal.integrated.allowMnemonics', "Whether to allow menubar mnemonics (for example Alt+F) to trigger the open of the menubar. Note that this will cause all alt keystrokes to skip the shell when true. This does nothing on macOS."),
		type: 'boolean',
		default: false
	},
	[TerminalSettingId.EnvMacOs]: {
		restricted: true,
		markdownDescription: localize('terminal.integrated.env.osx', "Object with environment variables that will be added to the VS Code process to be used by the terminal on macOS. Set to `null` to delete the environment variable."),
		type: 'object',
		additionalProperties: {
			type: ['string', 'null']
		},
		default: {}
	},
	[TerminalSettingId.EnvLinux]: {
		restricted: true,
		markdownDescription: localize('terminal.integrated.env.linux', "Object with environment variables that will be added to the VS Code process to be used by the terminal on Linux. Set to `null` to delete the environment variable."),
		type: 'object',
		additionalProperties: {
			type: ['string', 'null']
		},
		default: {}
	},
	[TerminalSettingId.EnvWindows]: {
		restricted: true,
		markdownDescription: localize('terminal.integrated.env.windows', "Object with environment variables that will be added to the VS Code process to be used by the terminal on Windows. Set to `null` to delete the environment variable."),
		type: 'object',
		additionalProperties: {
			type: ['string', 'null']
		},
		default: {}
	},
	[TerminalSettingId.EnvironmentChangesRelaunch]: {
		markdownDescription: localize('terminal.integrated.environmentChangesRelaunch', "Whether to relaunch terminals automatically if extensions want to contribute to their environment and have not been interacted with yet."),
		type: 'boolean',
		default: true
	},
	[TerminalSettingId.ShowExitAlert]: {
		description: localize('terminal.integrated.showExitAlert', "Controls whether to show the alert \"The terminal process terminated with exit code\" when exit code is non-zero."),
		type: 'boolean',
		default: true
	},
	[TerminalSettingId.WindowsUseConptyDll]: {
		restricted: true,
		markdownDescription: localize('terminal.integrated.windowsUseConptyDll', "Whether to use the experimental conpty.dll (v1.25.260303002) shipped with VS Code, instead of the one bundled with Windows."),
		type: 'boolean',
		tags: ['preview'],
		default: false,
		experiment: {
			mode: 'auto'
		},
	},
	[TerminalSettingId.SplitCwd]: {
		description: localize('terminal.integrated.splitCwd', "Controls the working directory a split terminal starts with."),
		type: 'string',
		enum: ['workspaceRoot', 'initial', 'inherited'],
		enumDescriptions: [
			localize('terminal.integrated.splitCwd.workspaceRoot', "A new split terminal will use the workspace root as the working directory. In a multi-root workspace a choice for which root folder to use is offered."),
			localize('terminal.integrated.splitCwd.initial', "A new split terminal will use the working directory that the parent terminal started with."),
			localize('terminal.integrated.splitCwd.inherited', "On macOS and Linux, a new split terminal will use the working directory of the parent terminal. On Windows, this behaves the same as initial."),
		],
		default: 'inherited'
	},
	[TerminalSettingId.WordSeparators]: {
		markdownDescription: localize('terminal.integrated.wordSeparators', "A string containing all characters to be considered word separators when double-clicking to select word and in the fallback 'word' link detection. Since this is used for link detection, including characters such as `:` that are used when detecting links will cause the line and column part of links like `file:10:5` to be ignored."),
		type: 'string',
		// allow-any-unicode-next-line
		default: ' ()[]{}\',"`─‘’“”|'
	},
	[TerminalSettingId.EnableFileLinks]: {
		description: localize('terminal.integrated.enableFileLinks', "Whether to enable file links in terminals. Links can be slow when working on a network drive in particular because each file link is verified against the file system. Changing this will take effect only in new terminals."),
		type: 'string',
		enum: ['off', 'on', 'notRemote'],
		enumDescriptions: [
			localize('enableFileLinks.off', "Always off."),
			localize('enableFileLinks.on', "Always on."),
			localize('enableFileLinks.notRemote', "Enable only when not in a remote workspace.")
		],
		default: 'on'
	},
	[TerminalSettingId.AllowedLinkSchemes]: {
		description: localize('terminal.integrated.allowedLinkSchemes', "An array of strings containing the URI schemes that the terminal is allowed to open links for. By default, only a small subset of possible schemes are allowed for security reasons."),
		type: 'array',
		items: {
			type: 'string'
		},
		default: [
			'file',
			'http',
			'https',
			'mailto',
			'vscode',
			'vscode-insiders',
		]
	},
	[TerminalSettingId.UnicodeVersion]: {
		type: 'string',
		enum: ['6', '11'],
		enumDescriptions: [
			localize('terminal.integrated.unicodeVersion.six', "Version 6 of Unicode. This is an older version which should work better on older systems."),
			localize('terminal.integrated.unicodeVersion.eleven', "Version 11 of Unicode. This version provides better support on modern systems that use modern versions of Unicode.")
		],
		default: '11',
		description: localize('terminal.integrated.unicodeVersion', "Controls what version of Unicode to use when evaluating the width of characters in the terminal. If you experience emoji or other wide characters not taking up the right amount of space or backspace either deleting too much or too little then you may want to try tweaking this setting.")
	},
	[TerminalSettingId.EnablePersistentSessions]: {
		description: localize('terminal.integrated.enablePersistentSessions', "Persist terminal sessions/history for the workspace across window reloads."),
		type: 'boolean',
		default: true
	},
	[TerminalSettingId.PersistentSessionReviveProcess]: {
		markdownDescription: localize('terminal.integrated.persistentSessionReviveProcess', "When the terminal process must be shut down (for example on window or application close), this determines when the previous terminal session contents/history should be restored and processes be recreated when the workspace is next opened.\n\nCaveats:\n\n- Restoring of the process current working directory depends on whether it is supported by the shell.\n- Time to persist the session during shutdown is limited, so it may be aborted when using high-latency remote connections."),
		type: 'string',
		enum: ['onExit', 'onExitAndWindowClose', 'never'],
		markdownEnumDescriptions: [
			localize('terminal.integrated.persistentSessionReviveProcess.onExit', "Revive the processes after the last window is closed on Windows/Linux or when the `workbench.action.quit` command is triggered (command palette, keybinding, menu)."),
			localize('terminal.integrated.persistentSessionReviveProcess.onExitAndWindowClose', "Revive the processes after the last window is closed on Windows/Linux or when the `workbench.action.quit` command is triggered (command palette, keybinding, menu), or when the window is closed."),
			localize('terminal.integrated.persistentSessionReviveProcess.never', "Never restore the terminal buffers or recreate the process.")
		],
		default: 'onExit'
	},
	[TerminalSettingId.HideOnStartup]: {
		description: localize('terminal.integrated.hideOnStartup', "Whether to hide the terminal view on startup, avoiding creating a terminal when there are no persistent sessions."),
		type: 'string',
		enum: ['never', 'whenEmpty', 'always'],
		markdownEnumDescriptions: [
			localize('hideOnStartup.never', "Never hide the terminal view on startup."),
			localize('hideOnStartup.whenEmpty', "Only hide the terminal when there are no persistent sessions restored."),
			localize('hideOnStartup.always', "Always hide the terminal, even when there are persistent sessions restored.")
		],
		default: 'never',
	},
	[TerminalSettingId.HideOnLastClosed]: {
		description: localize('terminal.integrated.hideOnLastClosed', "Whether to hide the terminal view when the last terminal is closed. This will only happen when the terminal is the only visible view in the view container."),
		type: 'boolean',
		default: true
	},
	[TerminalSettingId.CustomGlyphs]: {
		markdownDescription: localize('terminal.integrated.customGlyphs', "Whether to draw custom glyphs instead of using the font for the following unicode ranges:\n\n{0}\n\nThis will typically result in better rendering with continuous lines, even when line height and letter spacing is used. This feature only works when {1} is enabled.", [
			'- Box Drawing (U+2500-U+257F)',
			'- Block Elements (U+2580-U+259F)',
			'- Braille Patterns (U+2800-U+28FF)',
			'- Powerline Symbols (U+E0A0-U+E0D4, Private Use Area)',
			'- Progress Indicators (U+EE00-U+EE0B, Private Use Area)',
			'- Git Branch Symbols (U+F5D0-U+F60D, Private Use Area)',
			'- Symbols for Legacy Computing (U+1FB00-U+1FBFF)'
		].join('\n'), `\`#${TerminalSettingId.GpuAcceleration}#\``),
		type: 'boolean',
		default: true
	},
	[TerminalSettingId.RescaleOverlappingGlyphs]: {
		markdownDescription: localize('terminal.integrated.rescaleOverlappingGlyphs', "Whether to rescale glyphs horizontally that are a single cell wide but have glyphs that would overlap following cell(s). This typically happens for ambiguous width characters (eg. the roman numeral characters U+2160+) which aren't featured in monospace fonts. Emoji glyphs are never rescaled."),
		type: 'boolean',
		default: true
	},
	[TerminalSettingId.EnableKittyKeyboardProtocol]: {
		restricted: true,
		markdownDescription: localize('terminal.integrated.enableKittyKeyboardProtocol', "Whether to enable the kitty keyboard protocol, which allows a program in the terminal to request more detailed keyboard input reporting. This can, for example, enable `Shift+Enter` to be handled by the program."),
		type: 'boolean',
		default: true,
		tags: ['advanced']
	},
	[TerminalSettingId.EnableWin32InputMode]: {
		restricted: true,
		markdownDescription: localize('terminal.integrated.enableWin32InputMode', "Whether to enable the win32 input mode, which provides enhanced keyboard input support on Windows."),
		type: 'boolean',
		default: false,
		tags: ['experimental', 'advanced'],
		experiment: {
			mode: 'auto'
		}
	},
	[TerminalSettingId.ShellIntegrationEnabled]: {
		restricted: true,
		markdownDescription: localize('terminal.integrated.shellIntegration.enabled', "Determines whether or not shell integration is auto-injected to support features like enhanced command tracking and current working directory detection. \n\nShell integration works by injecting the shell with a startup script. The script gives VS Code insight into what is happening within the terminal.\n\nSupported shells:\n\n- Linux/macOS: bash, fish, pwsh, zsh\n - Windows: pwsh, git bash\n\nThis setting applies only when terminals are created, so you will need to restart your terminals for it to take effect.\n\n Note that the script injection may not work if you have custom arguments defined in the terminal profile, have enabled {1}, have a [complex bash `PROMPT_COMMAND`](https://code.visualstudio.com/docs/editor/integrated-terminal#_complex-bash-promptcommand), or other unsupported setup. To disable decorations, see {0}", '`#terminal.integrated.shellIntegration.decorationsEnabled#`', '`#editor.accessibilitySupport#`'),
		type: 'boolean',
		default: true
	},
	[TerminalSettingId.ShellIntegrationDecorationsEnabled]: {
		restricted: true,
		markdownDescription: localize('terminal.integrated.shellIntegration.decorationsEnabled', "When shell integration is enabled, adds a decoration for each command."),
		type: 'string',
		enum: ['both', 'gutter', 'overviewRuler', 'never'],
		enumDescriptions: [
			localize('terminal.integrated.shellIntegration.decorationsEnabled.both', "Show decorations in the gutter (left) and overview ruler (right)"),
			localize('terminal.integrated.shellIntegration.decorationsEnabled.gutter', "Show gutter decorations to the left of the terminal"),
			localize('terminal.integrated.shellIntegration.decorationsEnabled.overviewRuler', "Show overview ruler decorations to the right of the terminal"),
			localize('terminal.integrated.shellIntegration.decorationsEnabled.never', "Do not show decorations"),
		],
		default: 'both'
	},
	[TerminalSettingId.ShellIntegrationTimeout]: {
		restricted: true,
		markdownDescription: localize('terminal.integrated.shellIntegration.timeout', "Configures the duration in milliseconds to wait for shell integration after launch before declaring it's not there. The default value {0} uses a variable wait time based on whether shell integration injection is enabled and whether it's a remote window. Values between 1 and 499 are clamped to 500ms. Consider setting this to a large value if your shell starts very slowly.", '`-1`'),
		type: 'integer',
		minimum: -1,
		maximum: 60000,
		default: -1
	},
	[TerminalSettingId.ShellIntegrationQuickFixEnabled]: {
		restricted: true,
		markdownDescription: localize('terminal.integrated.shellIntegration.quickFixEnabled', "When shell integration is enabled, enables quick fixes for terminal commands that appear as a lightbulb or sparkle icon to the left of the prompt."),
		type: 'boolean',
		default: true
	},
	[TerminalSettingId.ShellIntegrationEnvironmentReporting]: {
		markdownDescription: localize('terminal.integrated.shellIntegration.environmentReporting', "Controls whether to report the shell environment, enabling its use in features such as {0}. This may cause a slowdown when printing your shell's prompt.", `\`#${TerminalContribSettingId.SuggestEnabled}#\``),
		type: 'boolean',
		default: product.quality !== 'stable'
	},
	[TerminalSettingId.SmoothScrolling]: {
		markdownDescription: localize('terminal.integrated.smoothScrolling', "Controls whether the terminal will scroll using an animation."),
		type: 'boolean',
		default: false
	},
	[TerminalSettingId.IgnoreBracketedPasteMode]: {
		markdownDescription: localize('terminal.integrated.ignoreBracketedPasteMode', "Controls whether the terminal will ignore bracketed paste mode even if the terminal was put into the mode, omitting the {0} and {1} sequences when pasting. This is useful when the shell is not respecting the mode which can happen in sub-shells for example.", '`\\x1b[200~`', '`\\x1b[201~`'),
		type: 'boolean',
		default: false
	},
	[TerminalSettingId.EnableImages]: {
		restricted: true,
		markdownDescription: localize('terminal.integrated.enableImages', "Enables image support in the terminal, this will only work when {0} is enabled. Sixel and iTerm's inline image protocol are supported on Linux and macOS. The kitty graphics protocol is supported on all platforms. On Windows, all image protocols will only work for versions of ConPTY >= v2 which is shipped with Windows itself, see also {1}. Images will currently not be restored between window reloads/reconnects. When enabled, transparency mode is also turned on in the terminal.", `\`#${TerminalSettingId.GpuAcceleration}#\``, `\`#${TerminalSettingId.WindowsUseConptyDll}#\``),
		type: 'boolean',
		default: false
	},
	[TerminalSettingId.FocusAfterRun]: {
		markdownDescription: localize('terminal.integrated.focusAfterRun', "Controls whether the terminal, accessible buffer, or neither will be focused after `Terminal: Run Selected Text In Active Terminal` has been run."),
		enum: ['terminal', 'accessible-buffer', 'none'],
		default: 'none',
		tags: ['accessibility'],
		markdownEnumDescriptions: [
			localize('terminal.integrated.focusAfterRun.terminal', "Always focus the terminal."),
			localize('terminal.integrated.focusAfterRun.accessible-buffer', "Always focus the accessible buffer."),
			localize('terminal.integrated.focusAfterRun.none', "Do nothing."),
		]
	},
	[TerminalSettingId.AllowInUntrustedWorkspace]: {
		restricted: true,
		markdownDescription: localize('terminal.integrated.allowInUntrustedWorkspace', "Controls whether terminals can be created in an untrusted workspace.\n\n**This feature bypasses a security protection that prevents terminals from launching in untrusted workspaces. The reason this is a security risk is because shells are often set up to potentially execute code automatically based on the contents of the current working directory. This should be safe to use provided your shell is set up in such a way that code execution in the folder never happens.**"),
		type: 'boolean',
		default: false
	},
	[TerminalSettingId.DeveloperPtyHostLatency]: {
		description: localize('terminal.integrated.developer.ptyHost.latency', "Simulated latency in milliseconds applied to all calls made to the pty host. This is useful for testing terminal behavior under high latency conditions."),
		type: 'number',
		minimum: 0,
		default: 0,
		tags: ['advanced']
	},
	[TerminalSettingId.DeveloperPtyHostStartupDelay]: {
		description: localize('terminal.integrated.developer.ptyHost.startupDelay', "Simulated startup delay in milliseconds for the pty host process. This is useful for testing terminal initialization under slow startup conditions."),
		type: 'number',
		minimum: 0,
		default: 0,
		tags: ['advanced']
	},
	[TerminalSettingId.DevMode]: {
		description: localize('terminal.integrated.developer.devMode', "Enable developer mode for the terminal. This shows additional debug information and visualizations for shell integration sequences."),
		type: 'boolean',
		default: false,
		tags: ['advanced']
	},
	...terminalContribConfiguration,
};

export async function registerTerminalConfiguration(getFontSnippets: () => Promise<IJSONSchemaSnippet[]>) {
	const configurationRegistry = Registry.as<IConfigurationRegistry>(Extensions.Configuration);
	configurationRegistry.registerConfiguration({
		id: 'terminal',
		order: 100,
		title: localize('terminalIntegratedConfigurationTitle', "Integrated Terminal"),
		type: 'object',
		properties: terminalConfiguration,
	});
	terminalConfiguration[TerminalSettingId.FontFamily].defaultSnippets = await getFontSnippets();
}

Registry.as<IConfigurationMigrationRegistry>(WorkbenchExtensions.ConfigurationMigration)
	.registerConfigurationMigrations([{
		key: TerminalContribSettingId.DeprecatedAgentSandboxEnabled,
		migrateFn: (value: unknown, valueAccessor) => {
			// The deprecated key `chat.agent.sandbox` is now also a namespace prefix
			// for new settings such as `chat.agent.sandbox.enabled` and
			// `chat.agent.sandbox.fileSystem.mac`. As a result, inspecting the
			// deprecated key may return an object representing the namespace tree
			// (e.g. `{ fileSystem: { mac: {...} } }`) even when the user never set
			// the original boolean setting. Only migrate when the value is actually
			// the original boolean type and skip writing back undefined to avoid
			// clobbering the new sub-settings.
			if (typeof value !== 'boolean') {
				return [];
			}
			const configurationKeyValuePairs: ConfigurationKeyValuePairs = [];
			if (valueAccessor(TerminalContribSettingId.AgentSandboxEnabled) === undefined) {
				configurationKeyValuePairs.push([TerminalContribSettingId.AgentSandboxEnabled, { value: value ? 'on' : 'off' }]);
			}
			configurationKeyValuePairs.push([TerminalContribSettingId.DeprecatedAgentSandboxEnabled, { value: undefined }]);
			return configurationKeyValuePairs;
		}
	}, {
		key: TerminalContribSettingId.DeprecatedAgentSandboxLinuxFileSystem,
		migrateFn: (value: { denyRead?: string[]; allowWrite?: string[]; denyWrite?: string[] }, valueAccessor) => {
			const configurationKeyValuePairs: ConfigurationKeyValuePairs = [];
			if (value !== undefined && valueAccessor(TerminalContribSettingId.AgentSandboxLinuxFileSystem) === undefined) {
				configurationKeyValuePairs.push([TerminalContribSettingId.AgentSandboxLinuxFileSystem, { value }]);
			}
			configurationKeyValuePairs.push([TerminalContribSettingId.DeprecatedAgentSandboxLinuxFileSystem, { value: undefined }]);
			return configurationKeyValuePairs;
		}
	}, {
		key: TerminalContribSettingId.DeprecatedAgentSandboxMacFileSystem,
		migrateFn: (value: { denyRead?: string[]; allowWrite?: string[]; denyWrite?: string[] }, valueAccessor) => {
			const configurationKeyValuePairs: ConfigurationKeyValuePairs = [];
			if (value !== undefined && valueAccessor(TerminalContribSettingId.AgentSandboxMacFileSystem) === undefined) {
				configurationKeyValuePairs.push([TerminalContribSettingId.AgentSandboxMacFileSystem, { value }]);
			}
			configurationKeyValuePairs.push([TerminalContribSettingId.DeprecatedAgentSandboxMacFileSystem, { value: undefined }]);
			return configurationKeyValuePairs;
		}
	}, {
		key: TerminalSettingId.EnableBell,
		migrateFn: (enableBell, accessor) => {
			const configurationKeyValuePairs: ConfigurationKeyValuePairs = [];
			let announcement = accessor('accessibility.signals.terminalBell')?.announcement ?? accessor('accessibility.alert.terminalBell');
			if (announcement !== undefined && !isString(announcement)) {
				announcement = announcement ? 'auto' : 'off';
			}
			configurationKeyValuePairs.push(['accessibility.signals.terminalBell', { value: { sound: enableBell ? 'on' : 'off', announcement } }]);
			configurationKeyValuePairs.push([TerminalSettingId.EnableBell, { value: undefined }]);
			configurationKeyValuePairs.push([TerminalSettingId.EnableVisualBell, { value: enableBell }]);
			return configurationKeyValuePairs;
		}
	}]);
