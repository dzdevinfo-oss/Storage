/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

import type { Parser, Query, QueryCapture, Tree } from '@vscode/tree-sitter-wasm';
import { RunOnceScheduler } from '../../../../../base/common/async.js';
import { BugIndicatingError, ErrorNoTelemetry } from '../../../../../base/common/errors.js';
import { Lazy } from '../../../../../base/common/lazy.js';
import { Disposable, MutableDisposable, toDisposable } from '../../../../../base/common/lifecycle.js';
import { posix, win32 } from '../../../../../base/common/path.js';
import { ITreeSitterLibraryService } from '../../../../../editor/common/services/treeSitter/treeSitterLibraryService.js';
import { ICommandFileWriteParser } from './commandParsers/commandFileWriteParser.js';
import { SedFileWriteParser } from './commandParsers/sedFileWriteParser.js';

export const enum TreeSitterCommandParserLanguage {
	Bash = 'bash',
	PowerShell = 'powershell',
}

/**
 * Matches a PowerShell command token of the form `-flag=` or `--flag=` at the
 * start of input or following whitespace. Used to work around a tree-sitter
 * PowerShell grammar limitation where POSIX-style `--flag=value` arguments
 * (e.g. `git log --format="a|b"`) are parsed as assignment expressions and
 * truncate the surrounding command.
 *
 * See https://github.com/microsoft/vscode/issues/294010
 * TODO: Remove once upstream tree-sitter PowerShell grammer is updated.
 */
const pwshFlagEqualsRegex = /(^|\s)(-{1,2}[\w-]+)=/g;

// TODO: Remove once upstream tree-sitter PowerShell grammer is updated.
function maskPwshFlagEquals(commandLine: string): string {
	return commandLine.replace(pwshFlagEqualsRegex, (_, pre, flag) => `${pre}${flag} `);
}

export class TreeSitterCommandParser extends Disposable {
	private readonly _parser: Lazy<Promise<Parser>>;
	private readonly _treeCache = this._register(new TreeCache());
	private readonly _commandFileWriteParsers: ICommandFileWriteParser[] = [
		new SedFileWriteParser(),
	];

	constructor(
		@ITreeSitterLibraryService private readonly _treeSitterLibraryService: ITreeSitterLibraryService,
	) {
		super();
		this._parser = new Lazy(() => this._treeSitterLibraryService.getParserClass().then(ParserCtor => new ParserCtor()));
	}

	async extractSubCommands(languageId: TreeSitterCommandParserLanguage, commandLine: string): Promise<string[]> {
		if (languageId === TreeSitterCommandParserLanguage.PowerShell) {
			const masked = maskPwshFlagEquals(commandLine);
			if (masked !== commandLine) {
				const captures = await this._queryTree(languageId, masked, '(command) @command');
				// Masked command line has identical character positions, so slice the original
				// to preserve the user-visible text (including the `=` characters).
				return captures.map(e => commandLine.substring(e.node.startIndex, e.node.endIndex));
			}
		}
		const captures = await this._queryTree(languageId, commandLine, '(command) @command');
		return captures.map(e => e.node.text);
	}

	async extractPwshDoubleAmpersandChainOperators(commandLine: string): Promise<QueryCapture[]> {
		const captures = await this._queryTree(TreeSitterCommandParserLanguage.PowerShell, commandLine, [
			'(',
			'  (pipeline',
			'    (pipeline_chain_tail) @double.ampersand)',
			')',
		].join('\n'));
		return captures;
	}

	async extractCommandKeywords(languageId: TreeSitterCommandParserLanguage, commandLine: string): Promise<string[]> {
		const captures = await this._queryTree(languageId, commandLine, '(command_name) @command');
		const keywords = new Set<string>();
		for (const capture of captures) {
			const normalized = this._normalizeCommandKeyword(capture.node.text);
			if (normalized) {
				keywords.add(normalized);
			}
		}
		return [...keywords];
	}

	async getFileWrites(languageId: TreeSitterCommandParserLanguage, commandLine: string): Promise<string[]> {
		let query: string;
		switch (languageId) {
			case TreeSitterCommandParserLanguage.Bash:
				query = [
					'(file_redirect',
					'  destination: [(word) (string (string_content)) (raw_string) (concatenation)] @file)',
				].join('\n');
				break;
			case TreeSitterCommandParserLanguage.PowerShell:
				query = [
					'(redirection',
					'  (redirected_file_name) @file)',
				].join('\n');
				break;
		}
		const captures = await this._queryTree(languageId, commandLine, query);
		return captures.map(e => e.node.text.trim());
	}

	/**
	 * Extracts file targets from commands that perform file writes beyond shell redirections.
	 * Uses registered command parsers (e.g., for `sed -i`) to detect command-specific file writes.
	 * Returns an array of file paths that would be modified.
	 */
	async getCommandFileWrites(languageId: TreeSitterCommandParserLanguage, commandLine: string): Promise<string[]> {
		// Currently only bash-like shells are supported for command-specific parsing
		if (languageId !== TreeSitterCommandParserLanguage.Bash) {
			return [];
		}

		// Query for all commands
		const query = '(command) @command';
		const captures = await this._queryTree(languageId, commandLine, query);

		const result: string[] = [];
		for (const capture of captures) {
			const commandText = capture.node.text;
			for (const parser of this._commandFileWriteParsers) {
				if (parser.canHandle(commandText)) {
					result.push(...parser.extractFileWrites(commandText));
				}
			}
		}
		return result;
	}

	private async _queryTree(languageId: TreeSitterCommandParserLanguage, commandLine: string, querySource: string): Promise<QueryCapture[]> {
		const { tree, query } = await this._doQuery(languageId, commandLine, querySource);
		return query.captures(tree.rootNode);
	}

	private _normalizeCommandKeyword(token: string): string | undefined {
		const unquoted = token.replace(/^['"]|['"]$/g, '');
		if (!unquoted) {
			return undefined;
		}

		const pathBase = unquoted.includes('\\') ? win32.basename(unquoted) : posix.basename(unquoted);
		const normalized = pathBase.toLowerCase().replace(/\.(?:exe|cmd|bat|ps1)$/i, '');
		return normalized || undefined;
	}

	private async _doQuery(languageId: TreeSitterCommandParserLanguage, commandLine: string, querySource: string): Promise<{ tree: Tree; query: Query }> {
		const language = await this._treeSitterLibraryService.getLanguagePromise(languageId);
		if (!language) {
			throw new BugIndicatingError('Failed to fetch language grammar');
		}

		let tree = this._treeCache.get(languageId, commandLine);
		if (!tree) {
			const parser = await this._parser.value;
			parser.setLanguage(language);
			const parsedTree = parser.parse(commandLine);
			if (!parsedTree) {
				throw new ErrorNoTelemetry('Failed to parse tree');
			}

			tree = parsedTree;
			this._treeCache.set(languageId, commandLine, tree);
		}

		const query = await this._treeSitterLibraryService.createQuery(language, querySource);
		if (!query) {
			throw new BugIndicatingError('Failed to create tree sitter query');
		}

		return { tree, query };
	}
}

/**
 * Caches trees temporarily to avoid reparsing the same command line multiple
 * times in quick succession.
 */
class TreeCache extends Disposable {
	private readonly _cache = new Map<string, Tree>();
	private readonly _clearScheduler = this._register(new MutableDisposable<RunOnceScheduler>());

	constructor() {
		super();
		this._register(toDisposable(() => this._cache.clear()));
	}

	get(languageId: TreeSitterCommandParserLanguage, commandLine: string): Tree | undefined {
		this._resetClearTimer();
		return this._cache.get(this._getCacheKey(languageId, commandLine));
	}

	set(languageId: TreeSitterCommandParserLanguage, commandLine: string, tree: Tree): void {
		this._resetClearTimer();
		this._cache.set(this._getCacheKey(languageId, commandLine), tree);
	}

	private _getCacheKey(languageId: TreeSitterCommandParserLanguage, commandLine: string): string {
		return `${languageId}:${commandLine}`;
	}

	private _resetClearTimer(): void {
		this._clearScheduler.value = new RunOnceScheduler(() => {
			this._cache.clear();
		}, 10000);
		this._clearScheduler.value.schedule();
	}
}
